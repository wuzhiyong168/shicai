//
//  WZYGreensInfo_TwoViewController.m
//   _1
//
//  Created by   on 14-10-15.
//  Copyright (c) 2014年  . All rights reserved.
//

#import "WZYGreensInfo_TwoViewController.h"
#import "WZYSeeInfoViewController.h"
#import "WZYLoacationSQLManager.h"
#import "UIImageView+WebCache.h"
@interface WZYGreensInfo_TwoViewController ()

@end

@implementation WZYGreensInfo_TwoViewController
{
    BOOL active;
    BOOL a;
    CGFloat imtro_height;
    UIScrollView * scrollView;
    BOOL isCollection;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.id_num = [[NSMutableString alloc]init];
        //创建一个imageView
        self.albumsimageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenWidth)];
        [self setShadowLayer:self.albumsimageView];
        self.PlistArray = [[NSMutableArray alloc]init];
        self.Plistid_Array = [[NSMutableArray alloc]init];
        active = true;
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = kBackgroundColor;

    self.title = [NSString stringWithFormat:@"%@",self.data[@"title"]];
    
    [self obtianSavePlist];
    [NetworkManaged requestNormalWithUrl:@"http://apis.juhe.cn/cook/category?key=d520219e8a556e618a9197274cea8547" complete:^(NSDictionary * _Nonnull dic) {
        if (dic) {
            [self beginInit];
        } else {
            
        }
    }];
    
    UIBarButtonItem *back = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"navi_back"] style:UIBarButtonItemStylePlain target:self action:@selector(didClickBack)];
    self.navigationItem.leftBarButtonItem = back;
}

-(void)didClickBack
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark -
-(void)obtianSavePlist
{
    //获取plist文件中的数据
    NSString *document = NSSearchPathForDirectoriesInDomains(9, 1, 1)[0];
    NSString *filename = [document stringByAppendingPathComponent:@"Save.plist"];
    self.PlistArray = [NSMutableArray arrayWithContentsOfFile:filename];
    
    for (int i= 0 ; i<self.PlistArray.count; i++) {
        
        [self.Plistid_Array addObject:self.PlistArray[i][@"id"] ];
    }
    
    if (self.PlistArray == nil) {
        self.PlistArray = [[NSMutableArray alloc]init];
        self.Plistid_Array = [[NSMutableArray alloc]init];
    }
    
    
    //创建一个收藏按钮
    self.collectButton = [[UIButton alloc] initWithFrame:CGRectMake(285, 20, 30, 30)];
    //设置按钮状态下的文字
    [self.collectButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];
    //设置按钮文字
    [self.collectButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    
    [self.collectButton addTarget:self action:@selector(_didClickButton:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    if ([self.Plistid_Array containsObject:self.data[@"id"]]==YES) {
        //设置按钮背景图片
        [self.collectButton setBackgroundImage:[UIImage imageNamed:@"56"] forState:UIControlStateNormal];
    }
    else{
        //设置按钮背景图片
        [self.collectButton setBackgroundImage:[UIImage imageNamed:@"55"] forState:UIControlStateNormal];
    }
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.collectButton];
    
}
- (void)setShadowLayer:(UIView *)view {
    view.layer.shadowOpacity = 0.5;
    view.layer.shadowOffset = CGSizeMake(0, 3);
}

#pragma mark - init
-(void)beginInit
{
    //创建一个ImageView并设置他的背景图片
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:self.view.bounds];
    
    [self.view addSubview:imageView];
    //    self.albumsimageView.image = [UIImage imageNamed:@"picture_loading"];
    //    [[WZYLoacationSQLManager sharedManager]loadImage:self.data[@"albums"][0] complection:^(id sender) {
    //        UIImage *image = sender;
    //        self.albumsimageView.image = image;
    
    __block WZYGreensInfo_TwoViewController *blockSelf = self;
    [self.albumsimageView sd_setImageWithURL:[NSURL URLWithString:self.data[@"albums"][0]] placeholderImage:[UIImage imageNamed:@"picture_loading"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType,NSURL *imageURL) {
        blockSelf.albumsimageView.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:blockSelf action:@selector(didClickImageForSeeing:)];
        [blockSelf.albumsimageView addGestureRecognizer:tap];
    }];
    
    
    //    }];
    
    
    [self.view addSubview:self.albumsimageView];
    ///////////////////////////////////////////////////////////////////////
    //    //创建一个收藏按钮
    //    UIButton *collectButton = [[UIButton alloc] initWithFrame:CGRectMake(285, 20, 30, 30)];
    //    //设置按钮状态下的文字
    //    [collectButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];
    //    //设置按钮文字
    //    [collectButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    //设置按钮背景图片
    //[collectButton setBackgroundImage:[UIImage imageNamed:@"1"] forState:UIControlStateNormal];
    
    //    [collectButton addTarget:self action:@selector(_didClickButton:) forControlEvents:UIControlEventTouchUpInside];
    //
    //    collectButton.tag = 1001;
    //
    //    [self.view addSubview:collectButton];
    ///////////////////////////////////////////////////////////////////////
    //创建一个ScrollView
    scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    //    //设置ScrollView的背景颜色
    //    scrollView.backgroundColor = [UIColor colorWithRed:0.2 green:0.3 blue:0.4 alpha:1];
    
    //设置是否回弹
    // scrollView.bounces = NO;
    //    //设置是否整页滚动
    //    scrollView.pagingEnabled = YES;
    //滚动视图圆角设置
    scrollView.layer.cornerRadius = 3;
    scrollView.layer.masksToBounds = YES;
    //禁止竖向滚动条滚动
    scrollView.showsVerticalScrollIndicator = NO;
    imageView.userInteractionEnabled = YES;
    [imageView addSubview:scrollView];
    // scrollView.backgroundColor = [UIColor redColor];
    
    
    //[albumsimageView setImage:[UIImage imageNamed:@"4"]];
    self.albumsimageView.backgroundColor = [UIColor lightGrayColor];
    [scrollView addSubview:self.albumsimageView];
    
    
    NSString *size_str = self.data[@"imtro"];
    //////////////////////////
    //适配
    CGSize size;
    NSDictionary *attribute = @{NSFontAttributeName: [UIFont systemFontOfSize:18]};
    size = [size_str boundingRectWithSize:CGSizeMake(kScreenWidth-20, 0) options: NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attribute context:nil].size;
    
    CGSize size1 = [self.data[@"ingredients"] boundingRectWithSize:CGSizeMake(kScreenWidth-20, 0) options: NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attribute context:nil].size;
    CGSize size2 = [self.data[@"burden"] boundingRectWithSize:CGSizeMake(kScreenWidth-20, 0) options: NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attribute context:nil].size;
    
    
    
    imtro_height = size.height+20;
    
    UILabel *ingre_label1 = [[UILabel alloc]initWithFrame:CGRectMake(10, _albumsimageView.bottom+25, CGRectGetWidth(self.view.bounds)-20, 25)];
    UILabel *ingre_label2 = [[UILabel alloc]initWithFrame:CGRectMake(10, ingre_label1.bottom+5+imtro_height, CGRectGetWidth(self.view.bounds)-20, 25)];
    UILabel *ingre_label3 = [[UILabel alloc]initWithFrame:CGRectMake(10, ingre_label2.bottom+5+size1.height+20, CGRectGetWidth(self.view.bounds)-20, 25)];
    UILabel *ingre_label4 = [[UILabel alloc]initWithFrame:CGRectMake(10, ingre_label3.bottom+5+size2.height+20, CGRectGetWidth(self.view.bounds)-20, 25)];
    
    ingre_label1.text = @"介绍:";
    ingre_label2.text = @"用料:";
    ingre_label3.text = @"调料:";
    ingre_label4.text = @"步骤:";
    
    ingre_label1.font = [UIFont boldSystemFontOfSize:24];
    ingre_label2.font = [UIFont boldSystemFontOfSize:24];
    ingre_label3.font = [UIFont boldSystemFontOfSize:24];
    ingre_label4.font = [UIFont boldSystemFontOfSize:24];
    
    ingre_label1.textColor = [UIColor colorWithRed:0.562 green:0.073 blue:0.001 alpha:1.000];
    ingre_label2.textColor = [UIColor colorWithRed:0.562 green:0.073 blue:0.001 alpha:1.000];
    ingre_label3.textColor = [UIColor colorWithRed:0.562 green:0.073 blue:0.001 alpha:1.000];
    ingre_label4.textColor = [UIColor colorWithRed:0.562 green:0.073 blue:0.001 alpha:1.000];
    
    ingre_label1.backgroundColor = [UIColor clearColor];
    ingre_label2.backgroundColor = [UIColor clearColor];
    ingre_label3.backgroundColor = [UIColor clearColor];
    ingre_label4.backgroundColor = [UIColor clearColor];
    
    [self setShadowLayer:ingre_label1];
    [self setShadowLayer:ingre_label2];
    [self setShadowLayer:ingre_label3];
    [self setShadowLayer:ingre_label4];

    [scrollView addSubview:ingre_label1];
    [scrollView addSubview:ingre_label2];
    [scrollView addSubview:ingre_label3];
    [scrollView addSubview:ingre_label4];
    
    //创建一个imtroLabel
    self.imtroLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, ingre_label1.bottom, size.width, size.height+20)];
    //创建一个ingredientsLabel
    self.ingredientsLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, ingre_label2.bottom, size1.width, size1.height+20)];
    //创建一个burdenLabel
    self.burdenLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, ingre_label3.bottom, size2.width, size2.height+20)];
    
    self.imtroLabel.text = self.data[@"imtro"];
    self.imtroLabel.font =  [UIFont systemFontOfSize:18];
    //设置自动换行
    self.ingredientsLabel.numberOfLines = 0;
    self.burdenLabel.numberOfLines = 0;
    self.imtroLabel.numberOfLines = 0;
    [scrollView addSubview:self.imtroLabel];
    
    self.ingredientsLabel.backgroundColor = [UIColor clearColor];
    self.burdenLabel.backgroundColor = [UIColor clearColor];
    self.imtroLabel.backgroundColor = [UIColor clearColor];
    
    
    self.ingredientsLabel.text = self.data[@"ingredients"];
    //  self.ingredientsLabel.backgroundColor = [UIColor yellowColor];
    [scrollView addSubview:self.ingredientsLabel];
    //self.ingredientsLabel.alpha = 0.5;
    //设置字体大小
    self.burdenLabel.font = [UIFont systemFontOfSize:18];
    //设置自动换行
    self.burdenLabel.numberOfLines = 0;
    self.burdenLabel.text = self.data[@"burden"];
    //  self.burdenLabel.backgroundColor = [UIColor redColor];
    [scrollView addSubview:self.burdenLabel];
    
    NSMutableArray *steps_ = self.data[@"steps"];
    
    CGFloat allHeight = 0;
    CGFloat contentHeight = ingre_label4.bottom+20;
    for (int index = 0; index < steps_.count; index++)
    {
        
        
        
        NSString *size_str = steps_[index][@"step"];
        //////////////////////////
        //适配
        CGSize size;
        NSDictionary *attribute = @{NSFontAttributeName: [UIFont systemFontOfSize:18]};
        size = [size_str boundingRectWithSize:CGSizeMake(kScreenWidth-90, 0) options: NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attribute context:nil].size;
        
        allHeight += 10;
        size.height +=10;
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(80, ingre_label4.bottom+allHeight, size.width, size.height)];
        
        label.backgroundColor = [UIColor clearColor];
        label.text = steps_[index][@"step"];
        label.textAlignment = 0;
        label.font = [UIFont systemFontOfSize:18];
        label.numberOfLines = 0;
        label.layer.borderWidth = 2;
        label.layer.borderColor = kBlue.CGColor;
        [scrollView addSubview:label];
        
        //创建一个ImageView
        UIImageView *imageview = [[UIImageView alloc] initWithFrame:CGRectMake(15, ingre_label4.bottom+allHeight, 50, 50)];
        imageview.layer.masksToBounds = YES;
        imageview.layer.borderWidth = 2;
        imageview.layer.borderColor = kBlue.CGColor;
        imageview.layer.cornerRadius = 3;

        imageview.tag = 10100+index;
        //手势
        
        NSString *image_str =steps_[index][@"img"];
        
        __block UIImageView *blockImageView = imageview;
        [imageview sd_setImageWithURL:[NSURL URLWithString:image_str] placeholderImage:[UIImage imageNamed:@"picture_loading"] options:0 completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType,NSURL *imageURL) {
            blockImageView.userInteractionEnabled = YES;
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didClickImageForSeeing:)];
            
            [blockImageView addGestureRecognizer:tap];
        }];
        
        imageview.backgroundColor = [UIColor lightGrayColor];
        [scrollView addSubview:imageview];
        
        if (size.height <=50) {
            allHeight += 55;
        }
        else{
            allHeight +=size.height;
            
        }
        
        contentHeight = label.bottom+30;
    }
    scrollView.contentSize = CGSizeMake(0,contentHeight);
}

-(float)current_device_version
{
    UIDevice *currentDevice = [UIDevice currentDevice];
    
    float currentDevice_float = [currentDevice.systemVersion floatValue];
    
    return currentDevice_float;
}
#pragma mark - click Button


-(void)_didClickButton: (UIButton *)sender
{
    // NSFileManager *manager = [NSFileManager defaultManager];
    NSString *document = NSSearchPathForDirectoriesInDomains(9, 1, 1)[0];
    NSString *filename = [document stringByAppendingPathComponent:@"Save.plist"];
    NSLog(@"%d",a);
    
    if ( [self.Plistid_Array containsObject:self.data[@"id"]]) {
        [self.collectButton setBackgroundImage:[UIImage imageNamed:@"55"] forState:UIControlStateNormal];
        [self.PlistArray removeObject:self.data];
        [self.PlistArray writeToFile:filename atomically:YES];
        [self.Plistid_Array removeObject:self.data[@"id"]];
        
    }
    else
    {
        NSLog(@"1==1=%@",self.Plistid_Array);
        NSLog(@"2==2=%@",self.data);
        [self.collectButton setBackgroundImage:[UIImage imageNamed:@"56"] forState:UIControlStateNormal];
        [self.PlistArray addObject:self.data];
        [self.PlistArray writeToFile:filename atomically:YES];
        [self.Plistid_Array addObject:self.data[@"id"]];
        
    }
    
    //[self reloadInputViews];
    
}


-(void)didClickImageForSeeing:(UITapGestureRecognizer *)tap
{
    WZYSeeInfoViewController *seeVC = [[WZYSeeInfoViewController alloc]init];
    UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:seeVC];
    UIImageView *temp = (UIImageView *)tap.view;
    
    seeVC.imageView = temp;
    navi.navigationBarHidden = YES;
    
    [self presentViewController:navi animated:YES completion:nil];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
