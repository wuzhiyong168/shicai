//
//  WZYSQLManager.h
//   _1
//
//  Created by   on 14-10-3.
//  Copyright (c) 2014年  . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WZYSQLManager : NSObject

//+(instancetype)sharedSQLManager;
//
//-(void)openSQL;
//-(void)createSQL;
//-(void)selectSQL;

@end
