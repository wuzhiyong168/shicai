//
//  WZYKindsViewController.m
//   _1
//
//  Created by   on 14-10-3.
//  Copyright (c) 2014年  . All rights reserved.
//

#import "WZYKindsViewController.h"
#import "WZYLoacationSQLManager.h"
#import "WZYBeganViewController.h"
#import "WZYSmallKindViewController.h"
#import "CCYCollectionViewController.h"


@interface WZYKindsViewController (){
    UISearchBar *searchBar;
}
@property (nonatomic,assign) NSInteger count;
@end

@implementation WZYKindsViewController
{
    NSArray *array;
    UIButton *webButton;
    
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UIView *view1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kStatusBarHeight)];
    view1.backgroundColor = kBlue;
    [self.view addSubview:view1];
    
//
    
  //  backImageView.image = [UIImage imageNamed:@"b9.jpg"];
    
//    backImageView.alpha = 0.6;
    self.idLists = [[NSMutableArray alloc]init];

    
    
    
    
   // NSLog(@"section=a=d=ad=%ld",(long)self.section);
    
    array = [[WZYLoacationSQLManager sharedManager]obtianGreensKindsInfo];
   
   // UILabel *searchLabel = [[UILabel alloc]initWithFrame:CGRectMake(5, 20, 80, 40)];
    searchBar = [[UISearchBar alloc]init];
    searchBar.delegate = self;
    searchBar.barTintColor = kBlue;
    searchBar.placeholder =@"菜谱名、食材名";
    searchBar.frame = CGRectMake(0, view1.bottom, kScreenWidth, 50);
//    searchBar.tintColor = [UIColor colorWithRed:0.850 green:0.774 blue:0.639 alpha:1.000];

    
  //  [self.view addSubview:searchLabel];
    [self.view addSubview:searchBar];
    
   // searchLabel.text = @"搜索菜名:";
   
    [NetworkManaged requestNormalWithUrl:@"http://apis.juhe.cn/cook/category?key=d520219e8a556e618a9197274cea8547" complete:^(NSDictionary * _Nonnull dic) {
        if (dic) {
            [self begin_init];
        } else {
            
        }
    }];
}

-(void)showAler
{
    [webButton removeFromSuperview];
  
}


#pragma mark -search bar delegate
- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    
    CCYCollectionViewController *collectionVC = (CCYCollectionViewController *)self.navigationController.tabBarController.viewControllers[1];
    collectionVC.isButtonClick = YES;
    
    self.navigationController.tabBarController.selectedIndex = 1;
    
  
   
    return NO;
}// return NO to not become first responder



#pragma mark -
//初始化
-(void)begin_init
{
    
    // [[WZYLoacationSQLManager sharedManager] obtianGreensKindsInfo][self.section][@"list"];
       //  NSLog(@"count=%d",self.count);
    CGFloat top = searchBar.bottom;
    UIScrollView *scrollView = [[UIScrollView alloc]init];
    scrollView.frame = CGRectMake(0, top, kScreenWidth, kScreenHeight-top-WD_TabBarHeight);
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.bounces=NO;
    kAdjustmentBehavior(self,scrollView);
    CGFloat scroll_height = 0;
    
    
    CGFloat scale = kScaleByScrennWidth;
    
    for (int jndex = 0; jndex<array.count; jndex++) {
        
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(19*scale, (15+94*jndex*3+jndex*40)*scale, 280, 20)];
    [scrollView addSubview:label];
    label.text = array[jndex][@"name"];
    label.font = [UIFont boldSystemFontOfSize:20];
    label.textColor = kBlue;
    for (int index = 0; index < [array[jndex][@"list"] count]; index++) {
       
        
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        UILabel *label = [[UILabel alloc]init];
        
        label.text = array[jndex][@"list"][index][@"name"];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont systemFontOfSize:14];
        label.textColor = kBlue;
        //////////////////////////
        //适配
        CGSize size;
        NSDictionary *attribute = @{NSFontAttributeName: [UIFont systemFontOfSize:14]};
        size = [label.text boundingRectWithSize:CGSizeMake(230, 0) options: NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attribute context:nil].size;

        
//        NSDictionary *attribute = @{NSFontAttributeName: [UIFont systemFontOfSize:14]};
//        CGSize size = [label.text boundingRectWithSize:CGSizeMake(230, 0) options: NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attribute context:nil].size;
//        if (size.width >= 70) {
//            label.frame = CGRectMake(14+74*(index%4)-(size.width-70)/2, 40+94*(index/4)+(40+94*3)*jndex+70, size.width, 20);
//        }
//        else
//        {
//            label.frame = CGRectMake(14+74*(index%4)-5, 40+94*(index/4)+(40+94*3)*jndex+70, 70, 20);
//        }
//        14+74*3 222 236 296 310
        label.frame = CGRectMake((19+74*(index%4))*scale-(size.width-60)/2, (40+94*(index/4)+(40+94*3)*jndex+70-5)*scale, size.width, 20);

        button.frame =CGRectMake((19+74*(index%4))*scale, (50+94*(index/4)+(40+94*3)*jndex)*scale, 60, 60);
        button.layer.masksToBounds = YES;
        button.layer.borderWidth = 1;
        button.layer.borderColor = kBlue.CGColor;
        button.layer.cornerRadius = 10;
        NSString *imageName = [NSString stringWithFormat:@"%d.jpg",index+9*jndex];
        UIImage *image_ = [UIImage imageNamed:imageName];
        if (image_ == NULL) {
            imageName = [NSString stringWithFormat:@"%d",index+9*jndex];
            image_ = [UIImage imageNamed:imageName];
        }
        if (image_ == NULL) {
            imageName = [NSString stringWithFormat:@"%d.jpeg",index+9*jndex];
            image_ = [UIImage imageNamed:imageName];
        }
        [button setBackgroundImage:image_ forState:UIControlStateNormal];
       // [button setTitle:array[jndex][@"list"][index][@"name"] forState:UIControlStateNormal];
        
        button.tag = 10000+index+jndex*9;
        [button addTarget:self action:@selector(didClickSelect:) forControlEvents:UIControlEventTouchUpInside];
       // [view addSubview:btn];
        [scrollView addSubview:button];
        [scrollView addSubview:label];
      //  [scrollView addSubview:view];
        
        scroll_height =button.bottom;
        //添加id
        [self.idLists addObject:array[jndex][@"list"][index][@"id"]];
      //  NSLog(@"idlist=%@",self.idLists);
    }
    }
    scrollView.contentSize = CGSizeMake(0, scroll_height+40);

     [self.view addSubview:scrollView];
}



//点击菜
-(void)didClickSelect:(UIButton *)button
{
    
    WZYSmallKindViewController *greensInfoVC = [[WZYSmallKindViewController     alloc]init];
    UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:greensInfoVC];
    NSInteger index_ = button.tag - 10000;
    greensInfoVC.id_num = self.idLists[index_];
    
    
        greensInfoVC.title = [NSString stringWithFormat:@"%@",array[index_/9][@"list"][index_%9][@"name"]];
    
    
    
//    greensInfoVC.navigationItem.title =array[index_/9][@"list"][index_%9][@"name"];
    //    [self.navigationController pushViewController:greensInfoVC animated:YES];
    [self.navigationController hh_presentCircleVC:navi point:button.center completion:nil];
    
}




@end
