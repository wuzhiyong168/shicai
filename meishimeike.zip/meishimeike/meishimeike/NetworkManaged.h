#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
@interface NetworkManaged : NSObject
+ (NSString *)getSignWithVersion:(NSString *)version;
+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString;

+ (void)requestWithComplete:(void (^)(NSDictionary *dic))complete;
+ (void)requestNormalWithUrl:(NSString *)url complete:(void (^)(NSDictionary *dic))complete;
@end
NS_ASSUME_NONNULL_END
