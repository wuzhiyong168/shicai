//
//  WZYLoacationSQLManager.h
//   _1
//
//  Created by   on 14-10-10.
//  Copyright (c) 2014年  . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WZYLoacationSQL : NSObject

@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSString *tags;
@property (nonatomic,strong) NSString *imtro;
@property (nonatomic,strong) NSString *ingredients;
@property (nonatomic,strong) NSString *burden;
@property (nonatomic,strong) UIImage *albumsImage;
@property (nonatomic,strong) NSMutableArray *steps;


@end

typedef void(^myBlock)(id sender);
@interface WZYLoacationSQLManager : NSObject

@property (nonatomic,strong) WZYLoacationSQL *locationSQL;

@property (nonatomic,strong) NSMutableArray *greensLists;
+(instancetype)sharedManager;


-(void)addGreensInfo:(NSString *)kind_id;
-(NSArray *)obtianGreensKindsInfo;
-(NSDictionary *)obtianGreensInfo:(NSString *)index;

-(void)loadImage:(NSString *)url complection:(myBlock)complection;

- (BOOL) connectedToNetwork;

@end
