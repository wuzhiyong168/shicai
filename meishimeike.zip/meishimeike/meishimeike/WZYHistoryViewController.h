//
//  WZYHistoryViewController.h
//   _1
//
//  Created by   on 14-10-17.
//  Copyright (c) 2014年  . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WZYHistoryViewController : UIViewController<UISearchBarDelegate,UIScrollViewDelegate>
@property (nonatomic,strong) UISearchBar *searchBar;
@property (nonatomic,strong) NSMutableArray *historyPlist;
@property (nonatomic,strong) UIScrollView *scrollView;

-(float)current_device_version;

@end
