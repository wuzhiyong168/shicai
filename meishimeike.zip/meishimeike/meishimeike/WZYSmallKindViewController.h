//
//  WZYSmallKindViewController.h
//   _1
//
//  Created by   on 14-10-11.
//  Copyright (c) 2014年  . All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WZYTableViewCell.h"

@interface WZYSmallKindViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) UITableView    *tableView;

@property (nonatomic,strong) NSMutableString *id_num;

@property (nonatomic,strong) NSMutableArray *greensInfos;
@end
