# ChooseDay
一个集天气预报、星座运势、老黄历为一身的超级无敌可直接拿去做毕业设计的项目

1.日历黄历

2.星座运势

3.天气预报

4.主题切换

日历黄历

![](http://oqspvtuxb.bkt.clouddn.com/18-8-20/20670819.jpg)

星座运势

![](http://i2.muimg.com/588926/2933de930921749c.png)

天气预报

![](http://oqspvtuxb.bkt.clouddn.com/18-8-20/44190572.jpg)

主题切换

![](http://oqspvtuxb.bkt.clouddn.com/18-8-20/87957112.jpg)

