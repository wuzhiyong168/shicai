//
//  CslendarCell.h
//  ChooseDay
//
//  Created by Rockeen on 16/1/28.
//  Copyright © 2016年 DreamThreeMusketeers. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CslendarCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *circleView;

@property (weak, nonatomic) IBOutlet UILabel *textLable;

@property (weak, nonatomic) IBOutlet UIButton *yesBtn;

@end
