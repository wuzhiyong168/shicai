//
//  ConstellationViewController.m
//  ChooseDay
//
//  Created by Rockeen on 16/1/16.
//  Copyright © 2016年 DreamThreeMusketeers. All rights reserved.
//

#import "ConstellationViewController.h"
#import "GUNMMAFN.h"

#import "MJExtension.h"
#import "ConstellationModel.h"

#import "iCarousel.h"


#import "CellView.h"


#import "PushViewController.h"


#import "AFNetworking.h"


@interface ConstellationViewController ()<iCarouselDataSource,iCarouselDelegate>
{
    //data
    NSMutableArray *_dataList;
    
    
    iCarousel *_icarous;
    
    
    NSInteger _assign;
    
    NSArray *_photoArr;
    
    NSArray *_monthArr;
    
    NSArray *_bgImgArr;
    
    NSMutableArray *requestDataArr;
}

@end

@implementation ConstellationViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor blackColor];
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:nil action:nil];
    
    self.navigationItem.backBarButtonItem = item;
    
    [self.navigationController.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], UITextAttributeTextColor, nil]];
    
    requestDataArr = [NSMutableArray array];
    _dataList = [NSMutableArray arrayWithObjects:@"0",@"1",@"2", nil];
    
    _photoArr = @[@"白羊a",@"金牛a",@"双子a",@"巨蟹a",@"狮子a",@"处女a",@"天秤a",@"天蝎a",@"射手a",@"摩羯a",@"水瓶a",@"双鱼a"];

    _monthArr = @[@"(3.21~4.19)",@"(4.20~5.20)",@"(5.21~6.21)",@"(6.22~7.22)",@"(7.23~8.22)",@"(8.23~9.22)",@"(9.23~10.23)",@"(10.24~11.22)",@"(11.23~12.21)",@"(12.22~1.19)",@"(1.20~2.18)",@"(2.19~3.20)"];

    _bgImgArr = @[@"白羊.jpg",@"金牛.jpg",@"双子.jpg",@"巨蟹.jpg",@"狮子.jpg",@"处女.jpg",@"天秤.jpg",@"天蝎.jpg",@"射手.jpg",@"摩羯.jpg",@"水瓶.jpg",@"双鱼.jpg"];
    
    
    //设置标题颜色
    [self setTitleColor];
    
    
    //创建collectionView
    [self createCollection];

    
    //判断是否有网
    [self  judgeTheNet];
    

}


//判断是否有网
- (void)judgeTheNet{
    
    
    AFNetworkReachabilityManager *reManager = [AFNetworkReachabilityManager sharedManager];
    
    // 提示：要监控网络连接状态，必须要先调用单例的startMonitoring方法
    [reManager startMonitoring];
    
    
    [reManager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        
        if (status) {
            //请求数据
            [self loadData];
            
        }
        else{
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"无法连接到互联网" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            
            alert.alertViewStyle = UIAlertViewStyleDefault;
            
            alert.tag = 11;
            
            [alert show];
        }
    }];
    
}

//创建collectionView
- (void)createCollection{
    

    _icarous = [[iCarousel alloc]initWithFrame:CGRectMake(0, 0, kScreenW, kScreenH-49-64)];
    
    _icarous.backgroundColor= kBgColor;
    _icarous.delegate = self;
    _icarous.dataSource = self;
    
    _icarous.type = iCarouselTypeCoverFlow2;
    
    _icarous.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_icarous];
    

}


//设置标题颜色
- (void)setTitleColor{
//    self.title = @"星座运势";
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithTitle:@"星座" style:UIBarButtonItemStylePlain target:nil action:nil];
    
    self.navigationItem.backBarButtonItem = item;
    
    [self.navigationController.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], UITextAttributeTextColor, nil]];
    
    
    UIImageView *backgroundImgV = [[UIImageView alloc]initWithFrame:self.view.bounds];
    
//    backgroundImgV.image = [UIImage imageNamed:@"星座背景.jpg"];
    
    
    [self.view addSubview:backgroundImgV];
}


//请求数据
- (void)loadData{
    
    //存放星座名称的数组
    NSArray *constellationArr = @[@"白羊座",@"金牛座",@"双子座",@"巨蟹座",@"狮子座",@"处女座",@"天秤座",@"天蝎座",@"射手座",@"摩羯座",@"水瓶座",@"双鱼座"];
    _assign = 0;
    //清空数组
    [_dataList removeAllObjects];
    
    //按十二星座先后顺序给_dataList赋值，用于添加model时候排序
    for (int i = 0; i < constellationArr.count; i++) {
        [_dataList addObject:constellationArr[i]];
    }
    [_icarous reloadData];
    return;
    
    //url
//    NSString *urlstr = @"http://web.juhe.cn:8080/constellation/getAll";

    //遍历数组获取星座数据
    for (int i = 0; i < constellationArr.count; i++) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(i * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self requestHttpWithI:i];
        });
    }
    
    
}
- (NSString *)getNowTime {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat: @"YYYYMMdd"];;
    NSDate *datenow = [NSDate date];
    NSString *currentTimeString = [formatter stringFromDate:datenow];
    return currentTimeString;
}
- (void)requestHttpWithI:(int)i {
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    NSString *catchString = [NSString stringWithFormat:@"%@i",[self getNowTime]];
    NSDictionary *catchData = [user objectForKey:catchString];
    if ([catchData isKindOfClass:[NSDictionary class]]&&catchData.count) {
        NSLog(@"星座缓存数据==%@",catchData);

        [self pushDetailVC:catchData withIndex:i];
        return;
    }
    
    NSString *urlstr = @"https://api.shenjian.io/constellation/today";

    
    NSDictionary *parameters = @{@"appid":@"6264cfd32c6b5f2f23919e1b121fc11b",@"constellation":_dataList[i]};
    MBProgressHUD *hub = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    @try{
        [GUNMMAFN getDataWithParameters:parameters withUrl:urlstr withBlock:^(id result) {
            NSLog(@"星座数据==%@",result);
            NSDictionary *dic = result[@"data"];
            if ([dic isKindOfClass:[NSDictionary class]]) {
                [self pushDetailVC:dic withIndex:i];
                [user setObject:dic forKey:catchString];
                [user synchronize];
            }
            [hub hide:YES afterDelay:0.5];
        } withFailedBlock:^(NSError *error) {
            [hub hide:YES];
            [MBProgressHUD showError:@"请求失败!" toView:self.view];
        }];
    }
    @catch(NSException *exception){
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:exception.reason delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        
        alert.alertViewStyle = UIAlertViewStyleDefault;
        
        alert.tag = 11;
        
        [alert show];
    }
    @finally{
        
    }
 
}
- (void)pushDetailVC:(NSDictionary *)dic withIndex:(int)index {
    PushViewController *pushV = [[PushViewController alloc]init];
    
    
    pushV.backgroundImg = [UIImage imageNamed:_bgImgArr[index]];
    
    pushV.hidesBottomBarWhenPushed = YES;
    pushV.model = dic;
    
    [self.navigationController pushViewController:pushV animated:YES];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}



#pragma mark-----iCarousel   代理
- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel{
    return _dataList.count;
}


- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view{
    
    
    //create new view if no view is available for recycling
    if (view == nil)
    {
        //don't do anything specific to the index within
        //this `if (view == nil) {...}` statement because the view will be
        //recycled and used with other index values later
//        view = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 200.0f, 200.0f)];
        view = [[[NSBundle mainBundle]loadNibNamed:@"CellView" owner:nil options:nil]lastObject];
        

        view.contentMode = UIViewContentModeCenter;
        
        view.backgroundColor = [UIColor colorWithRed:.5 green:.5 blue:.5 alpha:.3];
        
    }
    //                    if ([mod isKindOfClass:[NSString class]]) {

    NSArray *constellationArr = @[@"白羊座",@"金牛座",@"双子座",@"巨蟹座",@"狮子座",@"处女座",@"天秤座",@"天蝎座",@"射手座",@"摩羯座",@"水瓶座",@"双鱼座"];
    
    ((CellView *)view).nameLabel.text =[NSString stringWithFormat:@"%@  %@",constellationArr[index],_monthArr[index]];
    ((CellView *)view).image = [UIImage imageNamed:_photoArr[index]];
    
    
    return view;

}

- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value
{
    if (option == iCarouselOptionSpacing)
    {
        return value * 1.1;
    }
    return value;
}


- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index{
    
    [self requestHttpWithI:index];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
