//
//  GameViewController.h
//  ChooseDay
//
//  Created by Vivian on 16/3/3.
//  Copyright © 2016年 DreamThreeMusketeers. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GameViewController : UIViewController

@property (nonatomic,copy)UIImage *image;

@end
