//
//  ConstellationModel.m
//  ChooseDay
//
//  Created by 闵哲 on 16/2/27.
//  Copyright © 2016年 DreamThreeMusketeers. All rights reserved.
//

#import "ConstellationModel.h"

@implementation ConstellationModel

- (void)setDic:(NSDictionary *)dic {
    
}

@end
