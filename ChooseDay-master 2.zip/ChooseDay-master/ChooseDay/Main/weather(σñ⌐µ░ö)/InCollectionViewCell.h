//
//  InCollectionViewCell.h
//  ChooseDay
//
//  Created by 闵哲 on 16/1/19.
//  Copyright © 2016年 DreamThreeMusketeers. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WeatherModel.h"

@interface InCollectionViewCell : UICollectionViewCell


@property(nonatomic,retain)WeatherModel *model;

@end
