#import <Foundation/Foundation.h>
@interface MD5Encryption : NSObject
+ (NSString *)md5by32:(NSString*)input;
+ (NSString *)md5:(NSString *)str;
+ (NSString *)md5Min:(NSString *)str;
@end
