//
//  AnimationTiltBegin.h
//  https://github.com/yuwind/HHTransition
//
//  Created by 豫风 on 2018/4/19.
//  Copyright © 2018年 豫风. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnimationTiltBegin : NSObject<UIViewControllerAnimatedTransitioning>

@end
