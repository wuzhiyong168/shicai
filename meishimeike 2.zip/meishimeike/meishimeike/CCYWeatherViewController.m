//
//  CCYWeatherViewController.m
//   _1
//
//  Created by   on 14-10-13.
//  Copyright (c) 2014年  . All rights reserved.
//

#import "CCYWeatherViewController.h"
#import "WZYLoacationSQLManager.h"

@interface CCYWeatherViewController ()

@end

@implementation CCYWeatherViewController
{
    NSDictionary *dic_data;
    NSDictionary *dic_data2;
    UILabel *city_label;
    UILabel *temp1_label;
    UILabel *temp2_label;
    UILabel *weather_label;
    
    UILabel *shidu_label;
    UILabel *wdirection_label;
    UILabel *ws_label;
    UILabel *temp;
    
    UIImageView *imageView1;
    
    
    
    UIActivityIndicatorView *active;
    
    UIButton *webButton;
    
    
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (instancetype)init
{
    self = [super init];
    if (self) {
        
        
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    UIImageView *backImageView = [[UIImageView alloc]initWithFrame:self.view.bounds];
    
    [self.view addSubview:backImageView];
    backImageView.image = [UIImage imageNamed:@"b1"];
    
    [self weatherBegan];
    [self initBegan];
    
    
}
static int time_ = 1;
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    
    
    if ([[WZYLoacationSQLManager sharedManager]connectedToNetwork] && time_==1) {
        if (active != nil) {
            active = (UIActivityIndicatorView *)[self.view viewWithTag:100002];
        }
        else
        {
            active = [[UIActivityIndicatorView alloc]initWithFrame:CGRectMake(0, 0, 150, 150)];
            active.tag = 100002;
            [self.view addSubview:active];
            [active setCenter:CGPointMake(160, 240)];
            [active startAnimating];
            active.activityIndicatorViewStyle = 2;
            if (webButton != nil) {
                [webButton removeFromSuperview];
            }

        }
        
    }
    else if(![[WZYLoacationSQLManager sharedManager]connectedToNetwork] && dic_data == nil) {
        
        NSLog(@"无网");
        if (webButton != nil) {
            webButton = (UIButton *)[self.view viewWithTag:10001];
        }
        else
        {
       
        webButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        webButton.tag = 10001;
       // webButton.frame =CGRectMake(60, 200, 200, 60);
        webButton.frame = self.view.bounds;
        webButton.layer.borderWidth = 1;
        webButton.layer.cornerRadius = 10;
        webButton.userInteractionEnabled = NO;
        [webButton setTitle:@"亲!打开网络再来看吧!" forState:UIControlStateNormal];
        [webButton setBackgroundColor:[UIColor lightGrayColor]];
        
        
        [self.view addSubview:webButton];
        
        
       // [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(showAler) userInfo:nil repeats:NO];
        
    }
        
    }
    
    
}
-(void)showAler
{
    [webButton removeFromSuperview];
    
}
-(void)weatherBegan
{
    [[CCYWeatherInfoManager sharedManager]refreshcityInfo:^(id sender,id sender2) {
        NSLog(@"okoko");
        dic_data = sender;
        NSLog(@"dic=%@",dic_data);
        dic_data2 = sender2;
        NSLog(@"dic2=%@",dic_data2);

        
        NSDictionary *dic = dic_data[@"weatherinfo"];
        
        city_label.text = dic[@"city"];
        city_label.font = [UIFont systemFontOfSize:40];
        
        temp1_label.text = dic[@"temp1"];
        temp2_label.text = dic[@"temp2"];
        weather_label.text = dic[@"weather"];
        
        
        
        
        NSDictionary *dic2 = dic_data2[@"weatherinfo"];
        
        NSString *ws_str = dic2[@"WS"];
        wdirection_label.text = [dic2[@"WD"] stringByAppendingFormat:@"(%@)",ws_str];
        shidu_label.text = dic2[@"SD"];
        
        
        temp.text = [NSString stringWithFormat:@"%@℃(%@~%@)",dic2[@"temp"],dic[@"temp1"],dic[@"temp2"]];
        NSLog(@"%@",temp);
        
        
         [active stopAnimating];
        time_++;
    }];
 
}

-(void)initBegan
{
    
    city_label = [[UILabel alloc]initWithFrame:CGRectMake(150, 75, 170, 40)];
//    temp1_label = [[UILabel alloc]initWithFrame:CGRectMake(160, 150, 90, 30)];
//    temp2_label = [[UILabel alloc]initWithFrame:CGRectMake(160, 210, 90, 30)];
     temp = [[UILabel alloc]initWithFrame:CGRectMake(150, 130, 170, 30)];
    weather_label = [[UILabel alloc]initWithFrame:CGRectMake(150, 180, 170, 30)];
   // imageView1 = [[UIImageView alloc]initWithFrame:CGRectMake(160, 330, 150, 60)];
    shidu_label = [[UILabel alloc]initWithFrame:CGRectMake(150, 230, 170, 30)];
    wdirection_label = [[UILabel alloc]initWithFrame:CGRectMake(150, 280, 170, 30)];
   
    city_label.backgroundColor = [UIColor clearColor];
    temp1_label.backgroundColor = [UIColor clearColor];
    temp2_label.backgroundColor = [UIColor clearColor];
    weather_label.backgroundColor = [UIColor clearColor];
    wdirection_label.backgroundColor = [UIColor clearColor];
    shidu_label.backgroundColor = [UIColor clearColor];
    temp.backgroundColor = [UIColor clearColor];

//    city_label.textColor = [UIColor whiteColor];
//    temp1_label.textColor = [UIColor whiteColor];
//    temp2_label.textColor = [UIColor whiteColor];
//    weather_label.textColor = [UIColor whiteColor];
//    wdirection_label.textColor = [UIColor whiteColor];
//    shidu_label.textColor = [UIColor whiteColor];
//    temp.textColor = [UIColor whiteColor];
//
    city_label.font = [UIFont boldSystemFontOfSize:20];
    temp1_label.font = [UIFont systemFontOfSize:16];
    temp2_label.font = [UIFont systemFontOfSize:16];
    weather_label.font = [UIFont systemFontOfSize:20];
    wdirection_label.font = [UIFont systemFontOfSize:20];
    shidu_label.font = [UIFont systemFontOfSize:20];
    temp.font = [UIFont systemFontOfSize:20];
    
    [self.view addSubview:temp];
    [self.view addSubview:city_label];
//    [self.view addSubview:temp1_label];
//    [self.view addSubview:temp2_label];
    [self.view addSubview:weather_label];
   // [self.view addSubview:imageView1];
    [self.view addSubview:shidu_label];
    [self.view addSubview:wdirection_label];
    NSLog(@"okoko==");
    
    UILabel *city_ =[[UILabel alloc]initWithFrame:CGRectMake(50, 80, 60, 30)];
    UILabel *temp_ = [[UILabel alloc]initWithFrame:CGRectMake(50, 130, 60, 30)];
    UILabel *weather_ = [[UILabel alloc]initWithFrame:CGRectMake(50, 180, 60, 30)];
    UILabel *ws_ = [[UILabel alloc]initWithFrame:CGRectMake(50, 230, 60, 30)];
    UILabel *wd_ = [[UILabel alloc]initWithFrame:CGRectMake(50, 280, 60, 30)];
    
//    city_.textColor = [UIColor whiteColor];
//    temp_.textColor = [UIColor whiteColor];
//    weather_.textColor = [UIColor whiteColor];
//    ws_.textColor = [UIColor whiteColor];
//    wd_.textColor = [UIColor whiteColor];
    
    city_.font = [UIFont boldSystemFontOfSize:20];
    temp_.font = [UIFont boldSystemFontOfSize:20];
    weather_.font = [UIFont boldSystemFontOfSize:20];
    ws_.font = [UIFont boldSystemFontOfSize:20];
    wd_.font = [UIFont boldSystemFontOfSize:20];
    city_.backgroundColor = [UIColor clearColor];
    temp_.backgroundColor = [UIColor clearColor];
    weather_.backgroundColor = [UIColor clearColor];
    ws_.backgroundColor = [UIColor clearColor];
    wd_.backgroundColor = [UIColor clearColor];
    
    
    
    city_.text = @"城市:";
    temp_.text = @"温度:";
    weather_.text = @"天气:";
    ws_.text = @"湿度:";
    wd_.text = @"风向:";
    
    [self.view addSubview:city_];
    [self.view addSubview:temp_];
    [self.view addSubview:weather_];
    [self.view addSubview:ws_];
    [self.view addSubview:wd_];
}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
