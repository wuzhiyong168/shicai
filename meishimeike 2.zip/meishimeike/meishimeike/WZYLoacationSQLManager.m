//
//  WZYLoacationSQLManager.m
//   _1
//
//  Created by   on 14-10-10.
//  Copyright (c) 2014年  . All rights reserved.
//

#import "WZYLoacationSQLManager.h"
#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonHMAC.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <netdb.h>
#import <arpa/inet.h>
@implementation WZYLoacationSQL

-(void)dealloc
{
    self.title = nil;
    self.tags = nil;
    self.steps = nil;
    self.albumsImage = nil;
    self.burden = nil;
    self.imtro = nil;
    self.ingredients = nil;
    
    
}

@end

@implementation WZYLoacationSQLManager

+(instancetype)sharedManager
{
    static WZYLoacationSQLManager *locationManager = nil;
    
    static dispatch_once_t dispath;
    
    dispatch_once(&dispath, ^{
        locationManager = [[WZYLoacationSQLManager alloc]init];

    });
    
    return locationManager;
}

-(void)addGreensInfo:(NSString *)kind_id
{
//    NSString *kind_id_str = [NSString stringWithFormat:@"/test%@.plist",kind_id];
//    
//    NSString *documentPath = NSSearchPathForDirectoriesInDomains(9, 1, 1)[0];
//    NSString *filePath = [documentPath stringByAppendingString:kind_id_str];
    
    NSString *filePath1 = [[NSBundle mainBundle]pathForResource:[NSString stringWithFormat:@"test%@",kind_id] ofType:@"plist"];
 //   NSLog(@"path=%@",filePath);
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:filePath1];
   
    NSArray *dic_ =dic[@"result"][@"data"];
    self.greensLists = [[NSMutableArray alloc]initWithArray:dic_];
    //NSLog(@"addgreens=%@",self.greensLists);
}


-(NSArray *)obtianGreensKindsInfo
{
//    NSString *documentPath = NSSearchPathForDirectoriesInDomains(9, 1, 1)[0];
//    NSString *filePath = [documentPath stringByAppendingString:@"/greensKind.plist"];
  //  dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    NSLog(@"arrrr");
   
    NSString *filePath1 = [[NSBundle mainBundle] pathForResource:@"greensKind" ofType:@"plist"];
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:filePath1];
    
    return dic[@"result"];
}

-(NSDictionary *)obtianGreensInfo:(NSString *)index
{
    return self.greensLists[[index integerValue]];
}

-(void)loadImage:(NSString *)url complection:(myBlock)complection
{
    if (self.connectedToNetwork) {
      //  dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        
//        dispatch_async(queue, ^{
//            NSURLRequest *urlRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:url] cachePolicy:0 timeoutInterval:1.0f];
//            NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:url]];
//            if (data == nil) {
//                return;
//            }
//            UIImage *image = [UIImage imageWithData:data];
//            complection(image);
//           // NSLog(@"headdddd");
//        });
        
         NSURLRequest *urlRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:url] cachePolicy:0 timeoutInterval:10.0f];
        
        [NSURLConnection sendAsynchronousRequest:urlRequest queue:[[NSOperationQueue alloc]init] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
            [NSThread sleepForTimeInterval:3.0];
            UIImage *image = [UIImage imageWithData:data];
            
            complection(image);
        }];
        
    }
    
    
    
}


-(BOOL) connectedToNetwork
{
    // Create zero addy
    struct sockaddr_in zeroAddress;
    bzero(&zeroAddress, sizeof(zeroAddress));
    zeroAddress.sin_len = sizeof(zeroAddress);
    zeroAddress.sin_family = AF_INET;
    
    // Recover reachability flags
    SCNetworkReachabilityRef defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr *)&zeroAddress);
    SCNetworkReachabilityFlags flags;
    
    BOOL didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags);
    CFRelease(defaultRouteReachability);
    
    if (!didRetrieveFlags)
    {
        printf("Error. Could not recover network reachability flags\n");
        NSLog(@"不能连接上");
        return NO;
    }
    
    BOOL isReachable = ((flags & kSCNetworkFlagsReachable) != 0);
    BOOL needsConnection = ((flags & kSCNetworkFlagsConnectionRequired) != 0);
    return (isReachable && !needsConnection) ? YES : NO;
}

@end
