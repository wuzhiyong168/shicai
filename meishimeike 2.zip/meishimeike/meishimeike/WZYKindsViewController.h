//
//  WZYKindsViewController.h
//   _1
//
//  Created by   on 14-10-3.
//  Copyright (c) 2014年  . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WZYKindsViewController : UIViewController<UISearchBarDelegate>

//@property (nonatomic,assign) NSInteger section;

//id信息
@property (nonatomic,strong) NSMutableArray *idLists;

@end
