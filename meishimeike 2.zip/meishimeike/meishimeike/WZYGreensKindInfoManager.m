//
//  WZYGreensKindInfoManager.m
//   _1
//
//  Created by   on 14-10-2.
//  Copyright (c) 2014年  . All rights reserved.
//

#import "WZYGreensKindInfoManager.h"
#import "WZYLoacationSQLManager.h"

@implementation WZYGreensKindInfo



-(void)dealloc
{
    self.bigKinds_name = nil;
    self.bigKinds_num = nil;
    self.smallKinds_name = nil;
    
    self.id_num = nil;
}



@end


@implementation WZYGreensKindInfoManager

+(instancetype)sharedManager
{
    static WZYGreensKindInfoManager *s_greensKindInfoManager = nil;
    
   static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        s_greensKindInfoManager = [[WZYGreensKindInfoManager alloc]init];
        NSLog(@"dispatch_1");
    });
//        @synchronized(self)
//    {
//        if (s_greensKindInfoManager == nil) {
//            s_greensKindInfoManager = [[WZYGreensKindInfoManager alloc]init];
//        }
//    }
    return s_greensKindInfoManager;
}


- (instancetype)init
{
    self = [super init];
    if (self) {
       
        self.greensKinds = [[NSMutableArray alloc]init];
        self.greensKindInfo = [[WZYGreensKindInfo alloc]init];
            }
    
    
    return self;
}
//获得接口
-(void)getdata:(NSDictionary *)param completion:(CompletionBlock)completion
{
//#define kGreensKind @"http://apis.juhe.cn/cook/category?key=68eeee663f731baf76409a47452eeb48"
    
    if ([[WZYLoacationSQLManager sharedManager] connectedToNetwork]) {
#define kGreensKind @"http://apis.juhe.cn/cook/query?key=d520219e8a556e618a9197274cea85471&menu=%E8%A5%BF%E7%BA%A2%E6%9F%BF&rn=10&pn=3"
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        
        dispatch_async(queue, ^{
            NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:kGreensKind]];
            
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
            NSLog(@"dispatch_2");
            
            
            //下载完成后,返回主线程调用completion
            dispatch_async(dispatch_get_main_queue(), ^{
                NSLog(@"dispatch_3");
                
                completion(dic);
                NSLog(@"dispatch_4");
                
            });
            
        });
    }

    
    
    
}

-(void)searchGreens:(NSString *)name completion:(CompletionBlock)completion
{
    if ([[WZYLoacationSQLManager sharedManager] connectedToNetwork]) {
    #define kGreensInfo_ @"http://apis.juhe.cn/cook/query?key=d520219e8a556e618a9197274cea85471&menu=%@&rn=10&pn=3"
        
        
        
        [NetworkManaged requestNormalWithUrl:[NSString stringWithFormat:kGreensInfo_,name] complete:^(NSDictionary * _Nonnull dic) {
            NSLog(@"requestNormalWithUrl=%@",dic);
            if (completion) {
                if (dic[@"result"]==[NSNull null]||dic[@"result"]==nil) {
                    return;
                }
                completion(dic);
            }
        }];
        
        
        return;
//    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
//
//
//    dispatch_async(queue, ^{
//        NSLog(@"asdasd   queue");
//        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:kGreensInfo_,name]]];
//        if (data == nil) {
//            return;
//        }
//
//        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
//        NSLog(@"dispatch_2");
//
//        if (dic[@"result"]==[NSNull null]) {
//            return;
//        }
//
//        //下载完成后,返回主线程调用completion
//        dispatch_async(dispatch_get_main_queue(), ^{
//            NSLog(@"dispatch_3");
//
//            completion(dic);
//            NSLog(@"dispatch_4");
//
//        });
//
//    });
    
    }
}

//大分类
-(NSInteger)countForBigKinds
{
    return self.greensKinds.count;
}
//小分类
-(NSInteger)countForSmallKinds:(NSInteger)index
{
    NSLog(@"dic = = = %@",self.greensKinds[index]);
    NSDictionary *dic =self.greensKinds[index];
    NSArray *arr = [dic allValues][0];
    return arr.count;
}
//大分类名字
-(NSString *)obtainGreensBigKindName:(NSInteger)index
{
    NSDictionary *dic = self.greensKinds[index];
    return [dic allKeys][0];
}
//小分类
-(NSString *)obtainGreensSmallKindsAtIndex:(NSIndexPath *)indexPath
{
    NSDictionary *dic = self.greensKinds[indexPath.section];
    NSArray *array = [dic allValues][0];
    NSDictionary *dic1 = array[indexPath.row];
    
    NSLog(@"name=== =%@",dic1[@"name"]);
    
    return dic1[@"name"];
}
//得到每个菜的ID
-(NSString *)obtainGreensSmallKindsIdAtIndex:(NSIndexPath *)indexPath
{
    NSDictionary *dic = self.greensKinds[indexPath.section];
    NSArray *array = [dic allValues][0];
    NSDictionary *dic1 = array[indexPath.row];
    
    NSLog(@"ok?id=== =%@",dic1[@"id"]);
    
    return dic1[@"id"];
}

//每个菜个详细信息
-(void)getDetailData:(NSString *)id_num completion:(CompletionBlock)completion
{
#define kGreensDetailInfo @"http://apis.juhe.cn/cook/queryid?key=68eeee663f731baf76409a47452eeb48&id=%@"
    
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    dispatch_async(queue, ^{
        NSLog(@"okokid_num %@",id_num);
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:kGreensDetailInfo,id_num]]];
        
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
        NSLog(@"dispatch_2");
        
        
        //下载完成后,返回主线程调用completion
        dispatch_async(dispatch_get_main_queue(), ^{
            NSLog(@"dispatch_3");
            
            completion(dic);
            NSLog(@"dispatch_4");
            
        });
        
    });
    
    
}

@end
