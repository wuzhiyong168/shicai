//
//  WZYHistoryViewController.m
//   _1
//
//  Created by   on 14-10-17.
//  Copyright (c) 2014年  . All rights reserved.
//

#import "WZYHistoryViewController.h"
#import "WZYGreensInfo_TwoViewController.h"
#import "WZYBeganViewController.h"
#import "ZYLGreensInfoViewController.h"

@interface WZYHistoryViewController ()

@end

@implementation WZYHistoryViewController
{
    NSInteger scroll_y;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = kBackgroundColor;
    [self searchBarInit];
    //[self createLabel];
    
    UISwipeGestureRecognizer *swipe = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(scrollViewWillBeginDragging:)];
    
    swipe.direction = UISwipeGestureRecognizerDirectionUp | UISwipeGestureRecognizerDirectionDown;
    
    [self.view addGestureRecognizer:swipe];
    
}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    scroll_y = self.searchBar.bottom;
    self.searchBar.selectedScopeButtonIndex = 1;

    NSString *document = NSSearchPathForDirectoriesInDomains(9, 1, 1)[0];
    NSString *filename = [document stringByAppendingPathComponent:@"History.plist"];
    
    self.historyPlist = [[NSMutableArray alloc]initWithContentsOfFile:filename];
    [self scrollViewInit];
    [self createLabel];
    
//    [self.searchBar becomeFirstResponder];
//    [self.searchBar showsCancelButton];
    
    // [self swipe_KeyBoard];
}

//-(void)swipe_KeyBoard
//{
//    UISwipeGestureRecognizer *swipe = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(rebackKeyBoard)];
//    swipe.direction = UISwipeGestureRecognizerDirectionUp | UISwipeGestureRecognizerDirectionDown;
//
//    [self.scrollView addGestureRecognizer:swipe];
//}

-(void)rebackKeyBoard
{
    
    [self.searchBar resignFirstResponder];
}

-(void)viewDidDisappear:(BOOL)animated
{
    [self.searchBar resignFirstResponder];
    self.searchBar.showsCancelButton = NO;
    [self.scrollView removeFromSuperview];
}
-(void)searchBarInit {
    UIView *view1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kStatusBarHeight)];
    view1.backgroundColor = kBlue;
    [self.view addSubview:view1];
    //    self.view.backgroundColor = [UIColor colorWithRed:0.714 green:0.713 blue:0.737 alpha:1.000];
    self.searchBar = [[UISearchBar alloc]init];
    self.searchBar.delegate = self;
    
    self.searchBar.keyboardType = 0;
    self.searchBar.frame = CGRectMake(0, view1.bottom, kScreenWidth, 80);
    self.searchBar.placeholder =@"菜谱名、食材名";
    self.searchBar.barTintColor = kBlue;
    self.searchBar.tintColor = [UIColor whiteColor];

    [self.view addSubview:self.searchBar];
    self.searchBar.showsScopeBar = YES;
    self.searchBar.scopeButtonTitles = @[@"经典收藏",@"历史记录"];
   // self.searchBar.selectedScopeButtonIndex = 1;
 
    
    
    [self.view addSubview:self.searchBar];
    
    
}
static NSInteger scro_hei = 0;
-(void)scrollViewInit
{
    self.scrollView = [[UIScrollView alloc]init];
    
    self.scrollView.delegate = self;
    [self.view addSubview:self.scrollView];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    self.searchBar.showsCancelButton = NO;

    [self.searchBar resignFirstResponder];
}

#pragma mark - device system version

-(float)current_device_version
{
    UIDevice *currentDevice = [UIDevice currentDevice];
    
    float currentDevice_float = [currentDevice.systemVersion floatValue];
    
    return currentDevice_float;
}

-(void)createLabel
{
    
    NSInteger label_x = 10;
    NSInteger label_y = 10;
    
    
    for (int index = 0; index < self.historyPlist.count; index++) {
        
        NSDictionary *dic = self.historyPlist[index];
        
        UILabel *label = [[UILabel alloc]init];
        
        [self.scrollView addSubview:label];
        
        label.backgroundColor = [UIColor clearColor];
        label.text = dic[@"title"];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont systemFontOfSize:16];
        
        CGSize size;
        NSDictionary *attribute = @{NSFontAttributeName: [UIFont systemFontOfSize:16]};
        size = [dic[@"title"] boundingRectWithSize:CGSizeMake(0, 0) options: NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attribute context:nil].size;

        
        if (label_x+size.width>(kScreenWidth-10)) {
            label_x = 10;
            label_y += 30+5;
        }
        size.width+=5;
        label.frame = CGRectMake(label_x, label_y, size.width, 30);
        label.layer.borderWidth=1;
        label.layer.borderColor = kBlue.CGColor;
        label.layer.cornerRadius = 3;
        label.layer.masksToBounds = YES;
        label.tag = 101010+index;
        
        label.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didClickLabel:)];
        [label addGestureRecognizer:tap];
        
        if (label_x+size.width<=(kScreenWidth-10)) {
            label_x = label_x + size.width + 5;
            
        }
        
        
        scro_hei = label_y + 35;
        
    }
    if (scro_hei<CGRectGetHeight(self.view.bounds)-108) {
        self.scrollView.frame = CGRectMake(0, scroll_y, kScreenWidth, scro_hei+40);
    }
    else
    {
        self.scrollView.frame = CGRectMake(0, scroll_y, kScreenWidth, CGRectGetHeight(self.view.bounds)-148);
    }
    
    NSString *document = NSSearchPathForDirectoriesInDomains(9, 1, 1)[0];
    NSString *filename = [document stringByAppendingPathComponent:@"History.plist"];
    
    NSMutableArray *temp = [[NSMutableArray alloc]initWithContentsOfFile:filename];
    
    if (temp.count !=0 && temp !=nil) {
        UIButton *cleanButton = [UIButton buttonWithType:UIButtonTypeCustom];
        
        [cleanButton setTitle:@"清空历史记录" forState:UIControlStateNormal];
        [self.scrollView addSubview:cleanButton];
        cleanButton.frame = CGRectMake(0, 0, 120, 30);
        cleanButton.center = CGPointMake(160, scro_hei+30);
        
        [cleanButton addTarget:self action:@selector(clean_:) forControlEvents:UIControlEventTouchUpInside];
        
        self.scrollView.contentSize = CGSizeMake(kScreenWidth, scro_hei+71);
    }
    
    
    
    
    
}
-(void)clean_:(UIButton *)button
{
    NSString *document = NSSearchPathForDirectoriesInDomains(9, 1, 1)[0];
    NSString *filename = [document stringByAppendingPathComponent:@"History.plist"];
    
    NSMutableArray *temp = [[NSMutableArray alloc]initWithContentsOfFile:filename];
    [temp removeAllObjects];
    [temp writeToFile:filename atomically:YES];
    
    [self.scrollView removeFromSuperview];
    
    
    
    
    
}

-(void)didClickLabel:(UITapGestureRecognizer *)tap
{
    UILabel *label_ = (UILabel *)tap.view;
    
    WZYGreensInfo_TwoViewController *greensVC = [[WZYGreensInfo_TwoViewController alloc]init];
    UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:greensVC];
    greensVC.data = self.historyPlist[label_.tag-101010];
    
    [self presentViewController:navi animated:YES completion:nil];
}

#pragma mark -search bar delegate
- (void)searchBar:(UISearchBar *)searchBar selectedScopeButtonIndexDidChange:(NSInteger)selectedScope
{
    if (selectedScope == 0) {
        
        self.tabBarController.selectedIndex = 2;
    }
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    [searchBar setShowsCancelButton:YES animated:NO];
    return YES;
}// return NO to not become first responder

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
    return YES;
}// return NO to not resign first responder
- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    
}// called when text ends editing



- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    WZYBeganViewController *nextVC = [[WZYBeganViewController alloc]init];
    UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:nextVC];
    nextVC.greens_name =searchBar.text;
    
    
    
    [self presentViewController:navi animated:YES completion:nil];
    
    
}// called when keyboard search button pressed

- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar
{
    [searchBar setShowsCancelButton:NO animated:YES];
    [searchBar resignFirstResponder];
    searchBar.text = nil;
    self.tabBarController.selectedIndex=0;
}// called when cancel button pressed
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
