//
//  WZYGreensKindInfoManager.h
//   _1
//
//  Created by   on 14-10-2.
//  Copyright (c) 2014年  . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WZYGreensKindInfo : NSObject

@property (nonatomic,strong) NSString *bigKinds_name;
@property (nonatomic,strong) NSString *smallKinds_name;
@property (nonatomic,strong) NSString *bigKinds_num;
@property (nonatomic,strong) NSString *id_num;
@end

typedef void(^CompletionBlock)(id sender);


@protocol TableViewUpdate <NSObject>

-(void)tableViewUpdate;

@end

@interface WZYGreensKindInfoManager : NSObject

@property (nonatomic,strong) NSMutableArray *greensKinds;
@property (nonatomic,weak) id<TableViewUpdate>delegate;
@property (nonatomic,strong) WZYGreensKindInfo *greensKindInfo;
@property (nonatomic,strong) NSString *name_str;
+(instancetype)sharedManager;


//
-(void)getdata:(NSDictionary *)param completion:(CompletionBlock)completion;
//大分类个数
-(NSInteger)countForBigKinds;
//小分类个数
-(NSInteger)countForSmallKinds:(NSInteger)index;
//大分类名字
-(NSString *)obtainGreensBigKindName:(NSInteger)index;
//小分类
-(NSString *)obtainGreensSmallKindsAtIndex:(NSIndexPath *)indexPath;
//得到每个菜的ID
-(NSString *)obtainGreensSmallKindsIdAtIndex:(NSIndexPath *)indexPath;
//每个菜个详细信息
-(void)getDetailData:(NSString *)id_num completion:(CompletionBlock)completion;

-(void)searchGreens:(NSString *)name completion:(CompletionBlock)completion;

@end
