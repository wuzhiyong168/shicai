//
//  CCYCollectionViewController.h
//   _1
//
//  Created by   on 14-10-15.
//  Copyright (c) 2014年  . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CCYCollectionViewController : UIViewController<UISearchBarDelegate,UIScrollViewDelegate>


@property (nonatomic,strong) UISearchBar *searchBar;
@property (nonatomic,strong) NSMutableArray *savePlist;
@property (nonatomic,strong) UIScrollView *scrollView;
@property (nonatomic,assign) BOOL isButtonClick;
-(float)current_device_version;
@end
