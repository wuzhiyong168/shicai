//
//  SelectPicScrollView.m
//  LikeTanTanDemo
//
//  Created by apple on 2017/5/31.
//  Copyright © 2017年 apple. All rights reserved.
//

#import "SelectPicScrollView.h"

@interface SelectPicScrollView(){
    
    CGFloat                     _beginTimeStamp;
    CGPoint                     _beginPt;
    CGPoint                     _currentImgCenter;
    UIView*                     _currentView;
    UIView*                     _needRemoveView;
    BOOL                        _moveYes;
    NSMutableArray *     _dataArray;
    NSMutableArray *     _picViewArray;
    NSInteger                  _currentIndex;
    
    
}
@end

@implementation SelectPicScrollView
-(instancetype)initWithFrame:(CGRect)frame withDataArray:(NSMutableArray*)dataArray{
    self = [super initWithFrame:frame];
    if (self) {
        _currentIndex = 0;
        [_dataArray removeAllObjects];
        _dataArray = [NSMutableArray array];
        [_dataArray addObjectsFromArray:dataArray];
        _picViewArray = [NSMutableArray array];
        
        
    
        [self createView];
    }
    return self;
}

#pragma mark - -
-(void)createView{
    NSInteger picCount;
    if (_dataArray.count<kCurrentViewNum) {
        picCount = _dataArray.count;
    }else{
        picCount = kCurrentViewNum;
    }
   
    for (int i = 0; i<picCount; i++) {
        UIView *view = [self addVIewWithFrame:
                        CGRectMake(
                        kFirstViewFrameX+i*kImgViewRange,
                        kFirstPicFrameY+i*kImgViewRange*4,
                        kWidth-kFirstViewFrameX*2-i*kImgViewRange*2,
                        kWidth-kFirstViewFrameX*2-i*kImgViewRange*2+60)
                        andWithdataNum:i];
        [self insertSubview:view atIndex:0];
        [_picViewArray addObject:view];
        
        if (i == 0) {
            _currentView = _picViewArray[0];
            _currentImgCenter = _currentView.center;
        }
    }
    
    UIButton *leftBtn = [[UIButton alloc] init];
    leftBtn.frame = CGRectMake(20,25,50, 50);
    [leftBtn setImage:[UIImage imageNamed:@"toLeft"] forState:UIControlStateNormal];
    [self addSubview:leftBtn];
    [leftBtn addTarget:self action:@selector(leftBtnClick) forControlEvents:(UIControlEventTouchUpInside)];
    
    
    UIButton *rightBtn = [[UIButton alloc] init];
    rightBtn.frame = CGRectMake(kWidth-70,25,50, 50);
    [rightBtn setBackgroundImage:[UIImage imageNamed:@"toright"] forState:UIControlStateNormal];

    [self addSubview:rightBtn];
    [rightBtn addTarget:self action:@selector(rightBtnClick) forControlEvents:(UIControlEventTouchUpInside)];
    
    
}


#pragma mark - - 创建
-(UIView *)addVIewWithFrame:(CGRect)frame andWithdataNum:(NSInteger)dataNum{

    UIView *view = [[UIImageView alloc]init];
    view.backgroundColor = kBlue;
    view.frame =frame;
    view.layer.masksToBounds = YES;
    view.layer.cornerRadius =10;
    view.layer.borderWidth = 1;
    view.layer.borderColor = [[UIColor blackColor] CGColor];
    
    UIImageView *imgview = [[UIImageView alloc]init];
//    _dataArray[dataNum]
//    _dataArray[dataNum][@"albums"][0]
    [imgview sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",_dataArray[dataNum][@"albums"][0]]] placeholderImage:[UIImage imageNamed:@"picture_loading"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType,NSURL *imageURL) {
        
    }];
    imgview.frame = CGRectMake(0, 0, view.frame.size.width, view.frame.size.width);
    imgview.tag = 7;
    [view addSubview:imgview];
    
    UILabel *label = [[UILabel alloc]init];
    label.frame = CGRectMake(0, CGRectGetMaxX(imgview.frame), view.frame.size.width, 60);
    label.backgroundColor = [UIColor whiteColor];
    label.text = _dataArray[dataNum][@"title"];
    label.textAlignment = NSTextAlignmentCenter;
    label.tag = 8;
    [view addSubview:label];
    
    imgview.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    label.autoresizingMask = UIViewAutoresizingFlexibleWidth;
  
    imgview.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    label.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    
    return view;
}

#pragma mark - - 准备互动
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    //防止快速滑动控件堆积问题
    if (_needRemoveView !=nil) {
        [_needRemoveView removeFromSuperview];
        _needRemoveView = nil;
    }
    
    _beginTimeStamp = event.timestamp;
    _beginPt = [[touches anyObject] locationInView:self];
    
    //控件滑动范围
    if (kBeginPtYRange)
        _moveYes = YES;
    else
        _moveYes = NO;
    
}

#pragma mark - - 正在互动
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    CGPoint pt = [[touches anyObject] locationInView:self];
    CGFloat x = pt.x - _beginPt.x;
    CGFloat y = pt.y - _beginPt.y;
    
    //图片范围内响应
    if (_moveYes == YES) {
        _currentView.center = CGPointMake(_currentImgCenter.x + x,_currentImgCenter.y + y);
        _currentView.transform=CGAffineTransformMakeRotation(x/1000);
    }
}

#pragma mark - - 结束互动
-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    CGPoint pt = [[touches anyObject] locationInView:self];
    CGFloat distanceX =  pt.x -_beginPt.x;
    CGFloat timeStamp = _beginTimeStamp - event.timestamp;
    
    if (kBeginPtYRange&&fabs(distanceX)<10) {
        if ([_delegate respondsToSelector:@selector(clickCurrentViewWithIndex:)]) {
            [_delegate clickCurrentViewWithIndex:_currentIndex];
        }
    }
    
    //快速小范围滑动/*1*/
    if (fabs(timeStamp)<0.12f&&fabs(distanceX)>25) {
        if (distanceX>0){
            [self moveViewX:kRemoveRightX Y:pt.y andRemoveView:YES];
            if ([_delegate respondsToSelector:@selector(rightMoveEndWithIndex:)]) {
                [_delegate rightMoveEndWithIndex:_currentIndex-1];
            }
            
        }else{
            [self moveViewX:kRemoveLeftX Y:pt.y andRemoveView:YES];
            if ([_delegate respondsToSelector:@selector(leftMoveEndWithIndex:)]) {
                [_delegate leftMoveEndWithIndex:_currentIndex-1];
            }
        }
    
    //慢速大范围/*1*/
    }else{
        //向右
        if (distanceX>0) {
            if (distanceX>_currentView.frame.size.width/2) {
                [self moveViewX:kRemoveRightX Y:pt.y andRemoveView:YES];
                if ([_delegate respondsToSelector:@selector(rightMoveEndWithIndex:)]) {
                    [_delegate rightMoveEndWithIndex:_currentIndex-1];
                }
        
            }else{
                [self moveViewX:_currentImgCenter.x Y:_currentImgCenter.y andRemoveView:NO];
            }
            
        //向左
        }else{
            if ( fabs(distanceX)>_currentView.frame.size.width/2) {
                [self moveViewX:kRemoveLeftX Y:pt.y andRemoveView:YES];
                if ([_delegate respondsToSelector:@selector(leftMoveEndWithIndex:)]) {
                    [_delegate leftMoveEndWithIndex:_currentIndex-1];
                }
            
            }else{
                [self moveViewX:_currentImgCenter.x Y:_currentImgCenter.y andRemoveView:NO];
            }
        }
    } /*1*/
}

#pragma mark - -
-(void)moveViewX:(float)x Y:(float)y andRemoveView:(BOOL)isRemove{
    [UIView animateWithDuration:0.3 animations:^{
        _currentView.center = CGPointMake(x  ,  y);
        _currentView.transform=CGAffineTransformMakeRotation(0);
 
    } completion:^(BOOL finished) {
        [_needRemoveView removeFromSuperview];
        _needRemoveView = nil;
    }];
    
    if (isRemove == YES) {
        _currentIndex++;
        [_dataArray removeObjectAtIndex:0];
        
        if (_dataArray.count == 0) {
            self.userInteractionEnabled = NO;
            
        }else{
            self.userInteractionEnabled = YES;
            [self changeMoveView];
        }
    }
}

#pragma mark - -
-(void)changeMoveView{
    _needRemoveView = _picViewArray[0];
    [_picViewArray removeObjectAtIndex:0];
    
    NSInteger picCount;
    if (_dataArray.count<kCurrentViewNum) {
        picCount = _dataArray.count;
    }else{
        picCount = kCurrentViewNum;
        [_picViewArray addObject:[self addVIewWithFrame:
                        CGRectMake(
                        kFirstViewFrameX+(kCurrentViewNum-1)*kImgViewRange,
                        kFirstPicFrameY+(kCurrentViewNum-1)*kImgViewRange*4,
                        kWidth-kFirstViewFrameX*2-(kCurrentViewNum-1)*kImgViewRange*2,
                        kWidth-kFirstViewFrameX*2-(kCurrentViewNum-1)*kImgViewRange*2+60)
                        andWithdataNum:0]];
    }
    
    //
    for (int i = 0; i<picCount; i++) {
        UIView *view1 = _picViewArray[i];
        UIImageView *imgView1 = [view1 viewWithTag:7];
        UILabel *label1 = [view1 viewWithTag:8];
        [imgView1 sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",_dataArray[i][@"albums"][0]]] placeholderImage:[UIImage imageNamed:@"picture_loading"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType,NSURL *imageURL) {
            
        }];
        label1.text =_dataArray[i][@"title"];
        
        if (i == 0) {
            _currentView = view1;
            _currentImgCenter = _currentView.center;
        }
        if (picCount == kCurrentViewNum) {
            if (i!= picCount-1) {
                [UIView animateWithDuration:0.3 animations:^{
                    view1.frame =CGRectMake(kFirstViewFrameX+i*kImgViewRange, kFirstPicFrameY+i*kImgViewRange*4, kWidth-kFirstViewFrameX*2-i*kImgViewRange*2, kWidth-kFirstViewFrameX*2-i*kImgViewRange*2+60);
                    imgView1.frame = CGRectMake(0, 0, view1.frame.size.width, view1.frame.size.width);
                    
                    label1.frame = CGRectMake(0, CGRectGetMaxX(imgView1.frame), view1.frame.size.width, 60);
                }];
                
            }else{
                view1.frame =CGRectMake(kFirstViewFrameX+i*kImgViewRange, kFirstPicFrameY+i*kImgViewRange*4, kWidth-kFirstViewFrameX*2-i*kImgViewRange*2, kWidth-kFirstViewFrameX*2-i*kImgViewRange*2+60);
                imgView1.frame = CGRectMake(0, 0, view1.frame.size.width, view1.frame.size.width);
                label1.frame = CGRectMake(0, CGRectGetMaxX(imgView1.frame), view1.frame.size.width, 60);
                view1.alpha = 0;
                
                [UIView animateWithDuration:0.3 animations:^{
                    view1.alpha = 1;
                }];
                [self insertSubview:view1 atIndex:0];
            }
            
        }else{
            [UIView animateWithDuration:0.3 animations:^{
                view1.frame =CGRectMake(kFirstViewFrameX+i*kImgViewRange, kFirstPicFrameY+i*kImgViewRange*4, kWidth-kFirstViewFrameX*2-i*kImgViewRange*2, kWidth-kFirstViewFrameX*2-i*kImgViewRange*2+60);
                imgView1.frame = CGRectMake(0, 0, view1.frame.size.width, view1.frame.size.width);
                label1.frame = CGRectMake(0, CGRectGetMaxX(imgView1.frame), view1.frame.size.width, 60);
            }];
        }
        if (i == 0) {
            _currentView = view1;
            _currentImgCenter = _currentView.center;
        }
    }
}


-(void)rightBtnClick{
    NSLog(@"右边");
    [self moveViewX:kRemoveRightX Y:_currentImgCenter.y andRemoveView:YES];
    if ([_delegate respondsToSelector:@selector(rightMoveEndWithIndex:)]) {
        [_delegate rightMoveEndWithIndex:_currentIndex-1];
    }
}

-(void)leftBtnClick{
    [self moveViewX:kRemoveLeftX Y:_currentImgCenter.y andRemoveView:YES];
    if ([_delegate respondsToSelector:@selector(leftMoveEndWithIndex:)]) {
        [_delegate leftMoveEndWithIndex:_currentIndex-1];
    }
    NSLog(@"左边");
}

@end
