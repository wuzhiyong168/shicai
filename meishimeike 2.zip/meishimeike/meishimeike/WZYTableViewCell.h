//
//  WZYTableViewCell.h
//  meishimeike
//
//  Created by   on 14-11-5.
//  Copyright (c) 2014年  . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WZYTableViewCell : UITableViewCell
@property (nonatomic,strong) UIImageView *headView;

@property (nonatomic,strong) UILabel *titleLabel;
@end
