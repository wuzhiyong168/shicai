//
//  CCYWeatherInfoManager.m
//   _1
//
//  Created by   on 14-10-13.
//  Copyright (c) 2014年  . All rights reserved.
//

#import "CCYWeatherInfoManager.h"
#import "WZYLoacationSQLManager.h"

@implementation CCYWeatherInfo



@end

@implementation CCYWeatherInfoManager

+(instancetype)sharedManager
{
    static CCYWeatherInfoManager *s_Manager = nil;
    
   static dispatch_once_t oneTaken;
    
    dispatch_once(&oneTaken, ^{
         s_Manager = [[CCYWeatherInfoManager alloc]init];
    });
    
    return s_Manager;
}
- (void)refreshcityInfo:(weatherBlock)completion
{
    if ([[WZYLoacationSQLManager sharedManager]connectedToNetwork]) {
        
  
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    dispatch_async(queue, ^{

        //解析网址通过ip 获取城市天气代码
        NSURL *url = [NSURL URLWithString:@"http://61.4.185.48:81/g/"];
        
        //    定义一个NSError对象，用于捕获错误信息
        NSError *error;
        NSString *jsonString = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:&error];
        
       // NSLog(@"------------%@",jsonString);
        
        // 得到城市代码字符串，截取出城市代码
        NSString *Str;
        for (int i = 0; i<=[jsonString length]; i++)
        {
            for (int j = i+1; j <=[jsonString length]; j++)
            {
                Str = [jsonString substringWithRange:NSMakeRange(i, j-i)];
                if ([Str isEqualToString:@"id"]) {
                    if (![[jsonString substringWithRange:NSMakeRange(i+3, 1)] isEqualToString:@"c"]) {
                        _intString = [jsonString substringWithRange:NSMakeRange(i+3, 9)];
                    }
                }
            }
        }
        
        //中国天气网解析地址；
        NSString *path=@"http://www.weather.com.cn/data/cityinfo/%@.html";
        //将城市代码替换到天气解析网址cityNumber 部分！
       // path=[path stringByReplacingOccurrencesOfString:@"cityNumber" withString:_intString];
        path=[NSString stringWithFormat:path,_intString];
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:path]];
        if (data == nil) {
            return ;
        }
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        
      //  NSLog(@"path1 = %@",path);
        
        //中国天气网解析地址；
        NSString *path2=@"http://www.weather.com.cn/data/sk/%@.html";
        //将城市代码替换到天气解析网址cityNumber 部分！
        // path=[path stringByReplacingOccurrencesOfString:@"cityNumber" withString:_intString];
        path2=[NSString stringWithFormat:path2,_intString];
        NSDictionary *dic2 = [NSJSONSerialization JSONObjectWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:path2]] options:0 error:nil];

        //NSLog(@"path2 = %@",path2);
        
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(dic,dic2);
        });

    });
        
      }
    
}



@end
