//
//  WZYBeganViewController.h
//   _1
//
//  Created by   on 14-10-2.
//  Copyright (c) 2014年  . All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WZYTableViewCell.h"


@interface WZYBeganViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>


@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) NSString *greens_name;
@end
