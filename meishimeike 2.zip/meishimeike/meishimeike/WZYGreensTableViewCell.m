//
//  WZYGreensTableViewCell.m
//   _1
//
//  Created by   on 14-10-2.
//  Copyright (c) 2014年  . All rights reserved.
//

#import "WZYGreensTableViewCell.h"

@implementation WZYGreensTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.frame = CGRectMake(0, 0, kScreenWidth, 90);
        UILabel *label1 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0,CGRectGetWidth(self.bounds),CGRectGetHeight(self.bounds)*3/4)];
        UILabel *label2 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.bounds)*3/4,CGRectGetWidth(self.bounds),CGRectGetHeight(self.bounds)*1/4)];
        
        [self addSubview:label1];
        [self addSubview:label2];
        
        label1.backgroundColor = [UIColor yellowColor];
        label2.backgroundColor = [UIColor whiteColor];
        
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
