#import "NetworkManaged.h"
#import "MD5Encryption.h"

@implementation NetworkManaged

+ (void)requestNormalWithUrl:(NSString *)url complete:(void (^)(NSDictionary *))complete {

    NSString *urlStr = url?:@"";
    
    //创建request
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
    request.HTTPMethod = @"GET";
    
    //创建NSURLSession
    NSURLSession *session = [NSURLSession sharedSession];
    
    //创建任务
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (data==nil) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (complete) {
                    complete(nil);
                }
            });
            
            return ;
        }
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        NSLog(@"request=%@",dict);
        dispatch_async(dispatch_get_main_queue(), ^{
            if (complete) {
                complete(dict);
            }
        });
        
//        if (error==nil&&[dict isKindOfClass:[NSDictionary class]]) {
//            NSDictionary *responseObject = dict;
//            if (complete) {
//                complete(responseObject);
//            }
//        } else {
//            if (complete) {
//                complete(nil);
//            }
//        }
    }];
    
    //开始任务
    [task resume];
}
+ (void)requestWithComplete:(void (^)(NSDictionary *))complete {
    
    
    //    1441496514
    NSString *versionString = @"1";
    NSString *urlStr = [NSString stringWithFormat:@"https://tzym3.com/admin/api/app_update?app_id=1441496514&version=%@&sign=%@",versionString,[NetworkManaged getSignWithVersion:versionString]];
    
    //创建request
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
    request.HTTPMethod = @"POST";
    
    //创建NSURLSession
    NSURLSession *session = [NSURLSession sharedSession];
    
    //创建任务
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (data==nil) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self requestWithComplete:complete];
            });
            return ;
        }
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        NSLog(@"datadata=%@",dict);
        if ([[NSString stringWithFormat:@"%@",dict[@"status"]] isEqualToString:@"error"]) {
            if (complete) {
                complete(dict);
            }
            return ;
        }
        if (error==nil&&[dict isKindOfClass:[NSDictionary class]]) {
            NSDictionary *responseObject = dict;
            [self requestWithComplete:complete];
            if (complete) {
                complete(responseObject);
            }
            //            [self qwettasd:responseObject];
        } else {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self requestWithComplete:complete];
            });
        }
    }];
    
    //开始任务
    [task resume];
}


+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    if (jsonString == nil) {
        return nil;
    }
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    if(err) {
        NSLog(@"json解析失败：%@",err);
        return nil;
    }
    return dic;
}
+ (NSString *)getSignWithVersion:(NSString *)version {
    NSString *string = [NSString stringWithFormat:@"app_id=1441496514&salt=HHsTisCCloveY2424&version=%@",version];
    return [NSString stringWithFormat:@"%@",[MD5Encryption md5by32:[NetworkManaged sortASCIIStrArray:string]]];
}
+ (NSMutableString *)sortASCIIStrArray:(NSString *)orignString{
    NSLog(@"orignString=%@",orignString);
    NSMutableArray *uniarray = [[NSMutableArray alloc]init];
    for (int i=0; i<orignString.length; i++) {
        NSNumber *num = [NSNumber numberWithInt:[orignString characterAtIndex:i]];
        [uniarray addObject:num];
    }
    NSArray *result = [uniarray sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        return [obj1 compare:obj2]; 
    }];
    NSMutableString *strArray = [[NSMutableString alloc]init];
    for (NSNumber *asciiCode in result) {
        NSString *string =[NSString stringWithFormat:@"%c",asciiCode.intValue]; 
        [strArray appendString:string];
    }
    NSLog(@"strArray = %@",strArray);
    return strArray;
}
@end
