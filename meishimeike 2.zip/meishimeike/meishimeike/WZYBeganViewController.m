//
//  WZYBeganViewController.m
//   _1
//
//  Created by   on 14-10-2.
//  Copyright (c) 2014年  . All rights reserved.
//

#import "WZYBeganViewController.h"
#import "WZYGreensKindInfoManager.h"
#import "WZYKindsViewController.h"
#import "WZYLoacationSQLManager.h"
#import "ZYLGreensInfoViewController.h"
#import "UIImageView+WebCache.h"
@interface WZYBeganViewController (){
    UIImageView *_selectedImageView;
}

@end

@implementation WZYBeganViewController
{
    NSArray *array;
    NSString *name_;
    
     UIAlertView *aler;

}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        
        array = [[NSArray alloc]init];
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = kBackgroundColor;
    // Do any additional setup after loading the view.
//    NSString *document = NSSearchPathForDirectoriesInDomains(9, 1, 1)[0];
//    NSLog(@"%@",document);
    self.title = @"查询中...";
    
    
    //NSString *temp = [[NSString alloc]initWithString:[WZYGreensKindInfoManager sharedManager].name_str];
    //NSLog(@"tep = %@",temp);
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, CGRectGetHeight(self.view.bounds)) style:UITableViewStylePlain];
    self.tableView.tableFooterView = [UIView new];
    self.tableView.rowHeight = 60;
    UIBarButtonItem *back = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"navi_back"] style:UIBarButtonItemStylePlain target:self action:@selector(didClickBackButton)];
    
    self.navigationItem.leftBarButtonItem = back;
    
   
    
}

-(void)didClickBackButton
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if(![[WZYLoacationSQLManager sharedManager]connectedToNetwork] ) {
        
        NSLog(@"==无网");
        self.title = @"查询失败";
        aler = [[UIAlertView alloc]initWithTitle:@"亲!请打开网络再进行搜索!" message:nil delegate:self cancelButtonTitle:@"我知道了" otherButtonTitles:nil, nil];
        
        [aler show];
        
        
        
        
    }
    
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    NSLog(@"green:%@",self.greens_name);
    name_ = [self.greens_name stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    [[WZYGreensKindInfoManager sharedManager]searchGreens:name_ completion:^(id sender) {
        NSLog(@"search");
        NSDictionary *dic = sender;
        
        array = dic[@"result"][@"data"];
        if ([array isKindOfClass:[NSArray class]]) {
            self.title = @"查询成功";
            [self.tableView reloadData];
        } else {
            self.title = @"查询失败";
        }
        
        
        NSLog(@"searchGreenssearchGreens=%@",dic);
       
        
    }];
    
    
}


#pragma mark -table view

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return array.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    WZYTableViewCell *cell = nil;
    
    cell = [tableView dequeueReusableCellWithIdentifier:@"greens"];
    
    if (cell == nil) {
        
        cell = [[WZYTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"greens"];
        
    }
    
    
    [cell.headView sd_setImageWithURL:[NSURL URLWithString:array[indexPath.row][@"albums"][0]] placeholderImage:[UIImage imageNamed:@"picture_loading"] options:0 completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType,NSURL *imageURL) {
        
    }];
    cell.titleLabel.text = array[indexPath.row][@"title"];
    
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    WZYTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    _selectedImageView = cell.headView;
    
    ZYLGreensInfoViewController *kindsVC = [[ZYLGreensInfoViewController alloc]init];
    NSLog(@"index_row=%ld",(long)indexPath.row);

    kindsVC.data = array[indexPath.row];
    
    [self.navigationController hh_pushScaleViewController:kindsVC];

}
- (UIView *)hh_transitionAnimationView {
    return _selectedImageView;
}

#pragma mark - memory warning
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
