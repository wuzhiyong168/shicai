//
//  WZYSmallKindViewController.m
//   _1
//
//  Created by   on 14-10-11.
//  Copyright (c) 2014年  . All rights reserved.
//

#import "WZYSmallKindViewController.h"
#import "WZYLoacationSQLManager.h"
#import "ZYLGreensInfoViewController.h"
#import "UIImageView+WebCache.h"
@interface WZYSmallKindViewController ()
{
    UIImageView *_selectedImageView;
}


@end

@implementation WZYSmallKindViewController
{
   
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
 
    self.tableView = [[UITableView alloc]initWithFrame:self.view.bounds];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.rowHeight = 60;
    [self.tableView registerClass:[WZYTableViewCell class] forCellReuseIdentifier:@"WZYTableViewCell"];
  //  NSLog(@"%@",self.id_num);
    [self.view addSubview:self.tableView];
    [[WZYLoacationSQLManager sharedManager]addGreensInfo:self.id_num];
    self.greensInfos = [WZYLoacationSQLManager sharedManager].greensLists;
   // NSLog(@"array======%@",self.greensInfos);
    
    
    UIBarButtonItem *back = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"navi_back"] style:UIBarButtonItemStylePlain target:self action:@selector(didClickBackButton)];

    self.navigationItem.leftBarButtonItem = back;
    
    
}

-(void)didClickBackButton
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

#pragma  mark- table view
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.greensInfos.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    WZYTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"WZYTableViewCell"];
    
    cell.titleLabel.text = [NSString stringWithFormat:@"%@",self.greensInfos[indexPath.row][@"title"]];
//    [cell.headView sd_setImageWithURL:[NSURL URLWithString:self.greensInfos[indexPath.row][@"albums"][0]] placeholderImage:[UIImage imageNamed:@"picture_loading"]];
    [cell.headView sd_setImageWithURL:[NSURL URLWithString:self.greensInfos[indexPath.row][@"albums"][0]] placeholderImage:[UIImage imageNamed:@"picture_loading"]];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    WZYTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    _selectedImageView = cell.headView;
    
    ZYLGreensInfoViewController *greensVC = [[ZYLGreensInfoViewController alloc]init];
    
    greensVC.data = [WZYLoacationSQLManager sharedManager].greensLists[indexPath.row];
    
    
    NSString *document = NSSearchPathForDirectoriesInDomains(9, 1, 1)[0];
    NSString *filename = [document stringByAppendingPathComponent:@"History.plist"];
    
    NSMutableArray *history_arr = [[NSMutableArray alloc]initWithContentsOfFile:filename];
    if (history_arr == nil) {
        history_arr = [[NSMutableArray alloc]init];
    }
    
    if (![history_arr containsObject:[WZYLoacationSQLManager sharedManager].greensLists[indexPath.row]]) {
        [history_arr addObject:[WZYLoacationSQLManager sharedManager].greensLists[indexPath.row]];
        [history_arr writeToFile:filename atomically:YES];

    }
    

    
    
    [self.navigationController hh_pushScaleViewController:greensVC];
    
}

- (UIView *)hh_transitionAnimationView {
    return _selectedImageView;
}


@end
