//
//  SelectPicScrollView.h
//  LikeTanTanDemo
//
//  Created by apple on 2017/5/31.
//  Copyright © 2017年 apple. All rights reserved.
//

//控件x坐标
#define kFirstViewFrameX 20
//控件y坐标
#define kFirstPicFrameY  self.frame.size.height/2-(self.frame.size.width-kFirstViewFrameX*2)/2-60
//touch拖动范围
#define kBeginPtYRange _beginPt.y>kFirstPicFrameY&&_beginPt.y<CGRectGetMaxY(_currentView.frame)
//宽度
#define kWidth self.frame.size.width
//图片之间间隔距离
#define kImgViewRange 5
//当前页面的控件个数
#define kCurrentViewNum 3

//右边移除到中心点
#define kRemoveRightX kWidth+_currentView.frame.size.width
//左边移除到中心点
#define kRemoveLeftX 0-_currentView.frame.size.width


#import <UIKit/UIKit.h>
@protocol SelectPicScrollViewDelegate <NSObject>

@required
-(void)leftMoveEndWithIndex:(NSInteger)index;
-(void)rightMoveEndWithIndex:(NSInteger)index;
-(void)clickCurrentViewWithIndex:(NSInteger)index;
@end

@interface SelectPicScrollView : UIView
@property (nonatomic,strong)id<SelectPicScrollViewDelegate> delegate;
-(instancetype)initWithFrame:(CGRect)frame withDataArray:(NSMutableArray*)dataArray;
@end
