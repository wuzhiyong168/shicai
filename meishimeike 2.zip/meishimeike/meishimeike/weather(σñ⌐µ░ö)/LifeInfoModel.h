//
//  LifeInfoModel.h
//  ChooseDay
//
//  Created by 闵哲 on 16/1/18.
//  Copyright © 2016年 DreamThreeMusketeers. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LifeInfoModel : NSObject


@property(nonatomic,retain)NSArray *chuanyi;

@property(nonatomic,retain)NSArray *ganmao;

@property(nonatomic,retain)NSArray *kongtiao;

@property(nonatomic,retain)NSArray *wuran;

@property(nonatomic,retain)NSArray *xiche;

@property(nonatomic,retain)NSArray *yundong;

@property(nonatomic,retain)NSArray *ziwaixian;

@end
