//
//  GUNMMNavCityVC.h
//  ChooseDay
//
//  Created by 闵哲 on 16/2/23.
//  Copyright © 2016年 DreamThreeMusketeers. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GUNMMNavCityVC : UIViewController



@property(nonatomic,retain)NSString *cName;


@property (weak, nonatomic) IBOutlet UILabel *cityName;

@end
