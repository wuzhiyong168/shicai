//
//  CityCollectionViewCell.h
//  ChooseDay
//
//  Created by 闵哲 on 16/1/20.
//  Copyright © 2016年 DreamThreeMusketeers. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CityCollectionViewCell : UICollectionViewCell

@property(nonatomic,copy)NSString *cityName;



@property(nonatomic,retain)UILabel *label;

@end
