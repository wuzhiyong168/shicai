//
//  Pm25Model.m
//  ChooseDay
//
//  Created by 闵哲 on 16/1/18.
//  Copyright © 2016年 DreamThreeMusketeers. All rights reserved.
//

#import "Pm25Model.h"

@implementation Pm25Model

@end
