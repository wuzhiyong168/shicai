//
//  ChooseDayUse.h
//  ChooseDay
//
//  Created by 闵哲 on 2016/12/15.
//  Copyright © 2016年 DreamThreeMusketeers. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ChooseDayUse : NSObject

+ (void)showGoogleIconForView:(UIView *)view iconName:(NSString *)iconName color:(UIColor *)iconColor font:(CGFloat)iconFont suffix:(NSString *)suffix;



@end
