//
//  WeaInfoModel.h
//  ChooseDay
//
//  Created by 闵哲 on 16/1/18.
//  Copyright © 2016年 DreamThreeMusketeers. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WeaInfoModel : NSObject


@property(nonatomic,retain)NSArray *day;

@property(nonatomic,retain)NSArray *night;



@end
