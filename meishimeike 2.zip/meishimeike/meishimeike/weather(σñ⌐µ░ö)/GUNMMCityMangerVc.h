//
//  GUNMMCityMangerVc.h
//  ChooseDay
//
//  Created by 闵哲 on 16/2/22.
//  Copyright © 2016年 DreamThreeMusketeers. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GUNMMCityVC.h"

@interface GUNMMCityMangerVc : UIViewController


@property(nonatomic,retain)GUNMMCityVC *city;

@end
