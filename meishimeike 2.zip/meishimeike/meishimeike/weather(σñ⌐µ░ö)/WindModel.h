//
//  WindModel.h
//  ChooseDay
//
//  Created by 闵哲 on 16/1/18.
//  Copyright © 2016年 DreamThreeMusketeers. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WindModel : NSObject

@property(nonatomic,copy)NSString *windspeed;

@property(nonatomic,copy)NSString *power;

@property(nonatomic,copy)NSString *direct;

@end
