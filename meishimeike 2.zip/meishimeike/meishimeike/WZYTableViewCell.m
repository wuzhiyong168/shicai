//
//  WZYTableViewCell.m
//  meishimeike
//
//  Created by   on 14-11-5.
//  Copyright (c) 2014年  . All rights reserved.
//

#import "WZYTableViewCell.h"

@implementation WZYTableViewCell



- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.headView = [[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 40, 40)];
        self.titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(_headView.right+10, 0, kScreenWidth-100, 60)];
        
        [self.contentView addSubview:self.headView];
        [self.contentView addSubview:self.titleLabel];
        
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
