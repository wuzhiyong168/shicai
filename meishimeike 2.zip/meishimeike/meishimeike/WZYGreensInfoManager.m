//
//  WZYGreensInfoManager.m
//   _1
//
//  Created by   on 14-10-2.
//  Copyright (c) 2014年  . All rights reserved.
//

#import "WZYGreensInfoManager.h"

@implementation WZYGreensInfo

-(void)dealloc
{
    self.title = nil;
    self.tags = nil;
    self.steps = nil;
    self.albumsImage = nil;
    self.burden = nil;
    self.imtro = nil;
    self.ingredients = nil;
    
    
}

@end

@implementation WZYGreensInfoManager

+(instancetype)sharedManager
{
    static WZYGreensInfoManager *s_greensInfoManager = nil;
    
    @synchronized(self)
    {
        if (s_greensInfoManager == nil) {
            s_greensInfoManager = [[WZYGreensInfoManager alloc]init];
        }
    }
    
    return s_greensInfoManager;
}


-(WZYGreensInfo *)obtianGreensInfo:(NSString *)id_num;
{
    
    #define kGreensInfo @"http://apis.juhe.cn/cook/queryid?key=68eeee663f731baf76409a47452eeb48&id=%@"
    
    NSString *id_str = [id_num stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:kGreensInfo,id_str]]];
    
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
    NSDictionary *dic_data = dic[@"result"][@"data"][0];
    
    WZYGreensInfo *greensInfo = [[WZYGreensInfo alloc]init];
    
    greensInfo.title = dic_data[@"title"];
    greensInfo.tags = dic_data[@"tags"];
    greensInfo.albumsImage = dic_data[@"alnums"];
    greensInfo.imtro = dic_data[@"imtro"];
    greensInfo.ingredients = dic_data[@"ingredients"];
    greensInfo.steps = dic_data[@"steps"];
    greensInfo.burden = dic_data[@"burden"];
    
    return greensInfo;
}




@end
