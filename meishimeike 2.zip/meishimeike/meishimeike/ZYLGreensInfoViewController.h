//
//  ZYLGreensInfoViewController.h
//   _1
//
//  Created by   on 14-10-13.
//  Copyright (c) 2014年  . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZYLGreensInfoViewController : UIViewController
@property (nonatomic,strong) UILabel *titleLabel;
@property (nonatomic,strong) UILabel *tagsLabel;
@property (nonatomic,strong) UILabel *imtroLabel;
@property (nonatomic,strong) UILabel *ingredientsLabel;
@property (nonatomic,strong) UILabel *burdenLabel;
@property (nonatomic,strong) UIImageView *albumsimageView;

@property (nonatomic,strong) NSMutableString *id_num;
@property (nonatomic,strong) NSDictionary *data;

@property(nonatomic,strong)NSMutableArray *PlistArray;
//存储id
@property(nonatomic,strong)NSMutableArray *Plistid_Array;

@property(nonatomic,strong) UIButton *collectButton;


-(float)current_device_version;
@end
