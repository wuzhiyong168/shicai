//
//  WZYLoveFoodViewController.m
//  meishimeike
//
//  Created by 吴志勇 on 2018/11/15.
//  Copyright © 2018年 吴志勇. All rights reserved.
//

#import "WZYLoveFoodViewController.h"
#import "SelectPicScrollView.h"
#import "WZYLoacationSQLManager.h"
#import "ZYLGreensInfoViewController.h"

@interface WZYLoveFoodViewController ()<SelectPicScrollViewDelegate> {
    NSMutableArray *allFoods;
}
@property(nonatomic,strong)NSMutableArray *PlistArray;
//存储id
@property(nonatomic,strong)NSMutableArray *Plistid_Array;
@end

@implementation WZYLoveFoodViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    MBProgressHUD *hub = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [NetworkManaged requestNormalWithUrl:@"http://apis.juhe.cn/cook/category?key=d520242e8a5564352a9197274cea327" complete:^(NSDictionary * _Nonnull dic) {
        if (dic) {
            [self createView];
        } else {
            
        }
        [hub hideAnimated:YES];
    }];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self initInfo];
}
- (void)initInfo {
    NSString *document = NSSearchPathForDirectoriesInDomains(9, 1, 1)[0];
    NSString *filename = [document stringByAppendingPathComponent:@"Save.plist"];
    self.PlistArray = [NSMutableArray arrayWithContentsOfFile:filename];
    self.Plistid_Array = [NSMutableArray array];
    for (int i= 0 ; i<self.PlistArray.count; i++) {
        
        [self.Plistid_Array addObject:self.PlistArray[i][@"id"] ];
    }
}

-(void)createView{
    
    [[WZYLoacationSQLManager sharedManager] addGreensInfo:[NSString stringWithFormat:@"%d",arc4random_uniform(50)+1]];
    allFoods=[WZYLoacationSQLManager sharedManager].greensLists;
    
    
    SelectPicScrollView *picView = [[SelectPicScrollView alloc]initWithFrame:CGRectMake(0, WD_StatusHight, self.view.frame.size.width, self.view.frame.size.height-WD_StatusHight) withDataArray:allFoods];
    picView.delegate = self;
    [self.view addSubview:picView];
    
}

-(void)leftMoveEndWithIndex:(NSInteger)index{
    NSLog(@"向左移除-------------第index:%ld张",(long)index);
}


-(void)rightMoveEndWithIndex:(NSInteger)index{
    NSLog(@"向右移除-------------第index:%ld张",(long)index);
    NSString *document = NSSearchPathForDirectoriesInDomains(9, 1, 1)[0];
    NSString *filename = [document stringByAppendingPathComponent:@"Save.plist"];
    NSDictionary *dic = [WZYLoacationSQLManager sharedManager].greensLists[index];
    if ( [self.Plistid_Array containsObject:dic[@"id"]]) {
//        [self.PlistArray removeObject:dic];
//        [self.PlistArray writeToFile:filename atomically:YES];
//        [self.Plistid_Array removeObject:dic[@"id"]];
        
    }
    else
    {

        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 150, 50)];
        label.backgroundColor = [UIColor blackColor];
        label.textColor = [UIColor whiteColor];
        label.center = self.view.center;
        label.textAlignment = NSTextAlignmentCenter;
        label.layer.cornerRadius = 4;
        label.layer.masksToBounds = YES;
        label.text = @"收藏成功!";
        [self.view addSubview:label];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [label removeFromSuperview];
        });
        [self.PlistArray addObject:dic];
        [self.PlistArray writeToFile:filename atomically:YES];
        [self.Plistid_Array addObject:dic[@"id"]];
        
    }
}

-(void)clickCurrentViewWithIndex:(NSInteger)index{
    NSLog(@"点击-------------第index:%ld张",(long)index);
    
    
    ZYLGreensInfoViewController *greensVC = [[ZYLGreensInfoViewController alloc]init];
    greensVC.data = [WZYLoacationSQLManager sharedManager].greensLists[index];
    greensVC.hidesBottomBarWhenPushed = YES;

    
    [self.navigationController hh_pushErectViewController:greensVC];
}


@end
