//
//  WZYSeeInfoViewController.m
//   _1
//
//  Created by   on 14-10-14.
//  Copyright (c) 2014年  . All rights reserved.
//

#import "WZYSeeInfoViewController.h"

@interface WZYSeeInfoViewController ()

@end

@implementation WZYSeeInfoViewController
{
    float lastScale;
    UIImageView *imageView1;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
       


    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    if (self.navigationController) {
//        self.navigationController.navigationBarHidden = YES;
//    }
    imageView1 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0,kScreenWidth,200)];
    imageView1.center = CGPointMake(CGRectGetWidth(self.view.bounds)/2, CGRectGetHeight(self.view.bounds)/2);
    imageView1.backgroundColor = [UIColor grayColor];
    imageView1.image = self.imageView.image;
    imageView1.userInteractionEnabled = YES;
    
    [self.view addSubview:imageView1];
    self.view.backgroundColor = [UIColor blackColor];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didClickImage:)];
    [self.view addGestureRecognizer:tap];
    
    //捏合
    UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(scaGesture:)];
    [pinchRecognizer setDelegate:self];
    [self.view addGestureRecognizer:pinchRecognizer];
    

    
}

-(void)didClickImage:(UIImageView *)imageView
{
    NSLog(@"asfsff");
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)scaGesture:(id)sender {
    [self.view bringSubviewToFront:imageView1];
    //当手指离开屏幕时,将lastscale设置为1.0
    if([(UIPinchGestureRecognizer*)sender state] == UIGestureRecognizerStateEnded) {
        lastScale = 1.0;
        return;
    }
    
    CGFloat scale = 1.0 - (lastScale - [(UIPinchGestureRecognizer*)sender scale]);
    CGAffineTransform currentTransform = imageView1.transform;
    CGAffineTransform newTransform = CGAffineTransformScale(currentTransform, scale, scale);
    [imageView1 setTransform:newTransform];
    lastScale = [(UIPinchGestureRecognizer*)sender scale];
}
#pragma mark - UIGestureRecognizerDelegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return ![gestureRecognizer isKindOfClass:[UIPanGestureRecognizer class]];
}

- (UIView *)hh_transitionAnimationView {
    return self.imageView;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
