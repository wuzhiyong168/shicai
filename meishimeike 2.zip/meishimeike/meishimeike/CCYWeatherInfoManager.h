//
//  CCYWeatherInfoManager.h
//   _1
//
//  Created by   on 14-10-13.
//  Copyright (c) 2014年  . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CCYWeatherInfo : NSObject

@property(nonatomic,strong)NSString *city;


@end

typedef void(^weatherBlock)(id sender,id sender2);

@interface CCYWeatherInfoManager : NSObject
+(instancetype)sharedManager;

@property(nonatomic,strong)CCYWeatherInfo *citynameInfo;

@property(nonatomic,strong)NSString *citynameinfo;
@property(nonatomic,strong)NSString *weatherinfo;
@property(nonatomic,strong)NSString *tempinfo;
@property(nonatomic,strong)NSString *wind;
@property(nonatomic,strong)NSString *dressing_index;
@property(nonatomic,strong)NSString *dressing_advice;
@property(nonatomic,strong)NSString *travel_index;
@property(nonatomic,strong)NSString *exercise_index;
@property(nonatomic,strong)NSString *drying_index;
@property(retain,nonatomic)NSString *intString;


- (void)refreshcityInfo:(weatherBlock)completion;



@end
