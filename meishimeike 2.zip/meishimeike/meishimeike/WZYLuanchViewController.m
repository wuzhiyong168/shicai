//
//  WZYLuanchViewController.m
//  meishimeike
//
//  Created by 吴志勇 on 2018/11/10.
//  Copyright © 2018年 吴志勇. All rights reserved.
//

#import "WZYLuanchViewController.h"
#import "WZYKindsViewController.h"
#import "CCYCollectionViewController.h"
#import "WZYHistoryViewController.h"
#import "Lottie.h"

@interface WZYLuanchViewController ()

@property (strong, nonatomic) LOTAnimationView *animationView;


@end

@implementation WZYLuanchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initView];
    return;
    self.view.backgroundColor = kBackgroundColor;
    _animationView = [LOTAnimationView animationNamed:@"fish"];
    _animationView.loopAnimation = NO;
    _animationView.animationProgress=0.5;
//14 67 138
    _animationView.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.width);
    _animationView.center = self.view.center;
//    _animationView.contentMode = UIViewContentModeScaleAspectFit;
    [self.view addSubview:_animationView];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.01 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [_animationView playWithCompletion:^(BOOL animationFinished) {
            if (animationFinished) {
                NSLog(@"Remove");
                [_animationView removeFromSuperview];
                //            [self Resq];
                
            }
            [self initView];
        }];
    });
    
}

- (void)initView {
    WZYKindsViewController *kindVC = [[WZYKindsViewController alloc]init];
    UINavigationController *navi1 = [[UINavigationController alloc]initWithRootViewController:kindVC];
    navi1.navigationBarHidden = YES;
    navi1.title = @"菜谱";
    
    UIImage *image1 = [UIImage imageNamed:@"home"];
    navi1.tabBarItem.image = image1;
    
    CCYCollectionViewController *collectionVC = [[CCYCollectionViewController alloc] init];
    collectionVC.title = @"收藏";
    collectionVC.tabBarItem.image = [UIImage imageNamed:@"folder"];
    
    
    //历史记录
    WZYHistoryViewController *historyVC = [[WZYHistoryViewController alloc]init];
    historyVC.title = @"历史记录";
    historyVC.tabBarItem.image = [UIImage imageNamed:@"iconfont-baocun-2"];
    
    //标签
    UITabBarController *tabbarController = [[UITabBarController alloc]init];
    tabbarController.viewControllers = @[navi1,collectionVC,historyVC];
    tabbarController.tabBar.tintColor = kBlue;
    tabbarController.tabBar.translucent=NO;
    [UIApplication sharedApplication].keyWindow.rootViewController = tabbarController;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
